
import React, { useState, useEffect, useRef } from 'react';
import { X, Building2, MapPin, DollarSign, User, Phone, Save, Zap, Loader2, Link as LinkIcon, ShieldCheck, Hash, UserCheck, RefreshCw, Info, Tag, Image as ImageIcon, Plus, Trash2, Sparkles, Type as TypeIcon, SlidersHorizontal, UploadCloud, LayoutPanelTop, Pencil, Layers } from 'lucide-react';
import { Property, Broker, PropertyStatus } from '../types.ts';
import { extractPropertyFromUrl } from '../services/gemini.ts';

interface NewPropertyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddProperty: (property: Property) => void;
  onUpdateProperty?: (property: Property) => void;
  propertyToEdit?: Property | null;
  currentUser: Broker;
  brokers: Broker[];
  availableTypes: string[];
  availableStatuses: string[];
}

export const NewPropertyModal: React.FC<NewPropertyModalProps> = ({
  isOpen,
  onClose,
  onAddProperty,
  onUpdateProperty,
  propertyToEdit,
  currentUser,
  brokers = [],
  availableTypes = [],
  availableStatuses = [],
}) => {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const watermarkInputRef = useRef<HTMLInputElement>(null);
  
  const [displayPrice, setDisplayPrice] = useState('0,00');
  const [displayRentPrice, setDisplayRentPrice] = useState('0,00');
  const [gallery, setGallery] = useState<string[]>([]);

  const LISTING_TYPES = [
    'LANÇAMENTO',
    'APTO TERCEIRO',
    'CASA TERCEIROS',
    'CASA CONDOMINIO',
    'TERRENOS TERCEIROS',
    'TERRENO LANÇAMENTO',
    'TERRENOS EM CONDOMINIO'
  ];

  const generateCode = (type: string) => {
    const prefix = type ? type.charAt(0).toUpperCase() : 'I';
    const random = Math.floor(1000 + Math.random() * 9000);
    return `${prefix}-${random}`;
  };

  const initialFormData: Partial<Property> = {
    code: '',
    title: '',
    projectName: '',
    type: availableTypes?.[0] || 'Apartamento',
    listingType: LISTING_TYPES[0], 
    transactionType: 'Ambos',
    description: '',
    address: '',
    neighborhood: '',
    referencePoint: '',
    price: 0,
    rentPrice: 0,
    bedrooms: 0,
    bathrooms: undefined, 
    area: undefined,      
    status: availableStatuses?.[0] || PropertyStatus.AVAILABLE,
    imageUrl: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=800&q=80',
    acceptsExchange: false,
    ownerName: '',
    ownerPhone: '',
    watermarkText: 'VETTUS IMÓVEIS',
    watermarkImage: '',
    watermarkOpacity: 0.5,
    applyWatermark: true,
    brokerId: currentUser?.id || ''
  };

  const [formData, setFormData] = useState<Partial<Property>>(initialFormData);

  const formatCurrencyBRL = (value: number | string) => {
    const amount = typeof value === 'string' ? value.replace(/\D/g, '') : Math.round(Number(value) * 100).toString();
    const numericValue = parseInt(amount || '0') / 100;
    return new Intl.NumberFormat('pt-BR', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(numericValue);
  };

  const parseCurrencyToNumber = (formattedValue: string): number => {
    const cleanValue = formattedValue.replace(/\./g, '').replace(',', '.');
    return parseFloat(cleanValue) || 0;
  };

  const handlePriceChange = (value: string, setter: (v: string) => void, field: 'price' | 'rentPrice') => {
    const formatted = formatCurrencyBRL(value);
    setter(formatted);
    setFormData(prev => ({ ...prev, [field]: parseCurrencyToNumber(formatted) }));
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    Array.from(files as FileList).forEach((file: File) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        setGallery(prev => [...prev, reader.result as string]);
      };
      reader.readAsDataURL(file);
    });
  };

  const handleWatermarkUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      setFormData(prev => ({ ...prev, watermarkImage: reader.result as string }));
    };
    reader.readAsDataURL(file);
  };

  const removeImage = (index: number) => {
    setGallery(prev => prev.filter((_, i) => i !== index));
  };

  useEffect(() => {
    if (isOpen) {
      if (propertyToEdit) {
        setFormData(propertyToEdit);
        setDisplayPrice(formatCurrencyBRL(propertyToEdit.price));
        setDisplayRentPrice(formatCurrencyBRL(propertyToEdit.rentPrice || 0));
        setGallery(propertyToEdit.gallery || []);
      } else {
        const defaultType = availableTypes?.[0] || 'Apartamento';
        setFormData({
          ...initialFormData,
          brokerId: currentUser?.id || '',
          type: defaultType,
          code: generateCode(defaultType)
        });
        setDisplayPrice('0,00');
        setDisplayRentPrice('0,00');
        setGallery([]);
      }
    }
  }, [isOpen, propertyToEdit, currentUser]);

  const handleExtract = async () => {
    if (!url) return;
    setLoading(true);
    try {
      const data = await extractPropertyFromUrl(url);
      if (data && typeof data === 'object') {
        const newCode = data.type ? generateCode(data.type) : formData.code;
        setFormData(prev => ({
          ...prev,
          ...data,
          code: newCode
        }));
        if ('price' in data) setDisplayPrice(formatCurrencyBRL(data.price));
        if ('rentPrice' in data) setDisplayRentPrice(formatCurrencyBRL(data.rentPrice));
      }
    } catch (error) {
      console.error("Erro na extração:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;

    if (!formData.ownerName) {
      alert("O nome do proprietário é obrigatório.");
      return;
    }

    setIsSubmitting(true);
    try {
      const safeBrokers = brokers || [];
      const selectedBroker = safeBrokers.find(b => b.id === formData.brokerId) || currentUser;

      const propertyData: Property = {
        id: propertyToEdit?.id || Math.random().toString(36).substr(2, 9),
        brokerId: selectedBroker.id,
        brokerName: selectedBroker.name,
        code: formData.code || generateCode(formData.type || 'A'),
        title: formData.title || 'Imóvel sem título',
        projectName: formData.projectName || '',
        type: formData.type || 'Apartamento',
        listingType: formData.listingType || '',
        transactionType: 'Ambos',
        description: formData.description || '',
        address: formData.address || 'Endereço não informado',
        neighborhood: formData.neighborhood || '',
        referencePoint: formData.referencePoint || '',
        price: Number(formData.price) || 0,
        rentPrice: Number(formData.rentPrice) || 0,
        bedrooms: Number(formData.bedrooms) || 0,
        bathrooms: Number(formData.bathrooms) || 0,
        area: Number(formData.area) || 0,
        status: formData.status || PropertyStatus.AVAILABLE,
        imageUrl: gallery.length > 0 ? gallery[0] : formData.imageUrl || '',
        gallery: gallery,
        watermarkText: formData.watermarkText,
        watermarkImage: formData.watermarkImage,
        watermarkOpacity: formData.watermarkOpacity,
        applyWatermark: formData.applyWatermark,
        coordinates: formData.coordinates || { lat: -23.5505, lng: -46.6333 },
        acceptsExchange: !!formData.acceptsExchange,
        ownerName: formData.ownerName,
        ownerPhone: formData.ownerPhone || '',
        updatedAt: new Date().toISOString()
      };
      
      if (propertyToEdit && onUpdateProperty) {
        onUpdateProperty(propertyData);
      } else {
        onAddProperty(propertyData);
      }
      onClose();
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-[#0a1120]/95 backdrop-blur-md" onClick={onClose}></div>
      <div className="bg-white w-full max-w-3xl rounded-[2.5rem] p-0 relative z-10 shadow-2xl animate-in zoom-in duration-300 overflow-hidden max-h-[90vh] flex flex-col border border-white/10">
        
        <div className="navy-gradient p-8 text-white shrink-0 border-b border-white/5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-4">
              <div className="w-14 h-14 gold-gradient rounded-2xl flex items-center justify-center shadow-lg">
                {propertyToEdit ? <Pencil className="w-7 h-7 text-white" /> : <Building2 className="w-7 h-7 text-white" />}
              </div>
              <div>
                <h2 className="text-2xl font-bold uppercase tracking-tight">{propertyToEdit ? 'Edição de Captação' : 'Captação Vettus'}</h2>
                <p className="text-slate-400 text-sm">{propertyToEdit ? `Editando REF: ${propertyToEdit.code}` : 'Controle de propriedades e curadoria visual.'}</p>
              </div>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors text-white">
              <X className="w-7 h-7" />
            </button>
          </div>

          {!propertyToEdit && (
            <div className="bg-white/5 p-4 rounded-2xl border border-white/10 backdrop-blur-sm">
              <label className="text-[10px] font-bold text-[#d4a853] uppercase tracking-widest mb-2 block">Extração Inteligente por Link</label>
              <div className="flex space-x-2">
                <div className="relative flex-1">
                  <LinkIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
                  <input 
                    type="text" 
                    value={url}
                    onChange={e => setUrl(e.target.value)}
                    placeholder="Link do anúncio de referência..."
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-2 pl-10 pr-4 text-sm text-white outline-none focus:ring-1 focus:ring-[#d4a853]"
                  />
                </div>
                <button 
                  type="button"
                  onClick={handleExtract}
                  disabled={loading || !url}
                  className="bg-[#d4a853] hover:bg-[#b8860b] text-white px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 disabled:opacity-50"
                >
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
                  <span>{loading ? 'Processando...' : 'Extrair Dados'}</span>
                </button>
              </div>
            </div>
          )}
        </div>

        <form onSubmit={handleSubmit} className="overflow-y-auto p-8 bg-slate-50 space-y-8 no-scrollbar flex-1">
          
          <section className="bg-white p-6 rounded-3xl border border-[#d4a853]/20 shadow-sm space-y-4">
            <h3 className="text-[11px] font-black uppercase tracking-[0.2em] text-[#d4a853] flex items-center">
               <ShieldCheck className="w-4 h-4 mr-2" />
               Cadastro de Proprietário
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase ml-1">Nome Completo</label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input type="text" required value={formData.ownerName} onChange={e => setFormData({...formData, ownerName: e.target.value})} placeholder="Dono do imóvel" className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3.5 pl-12 pr-4 text-sm font-bold text-slate-900 outline-none focus:ring-2 focus:ring-[#d4a853]/20" />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase ml-1">WhatsApp</label>
                <div className="relative">
                  <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input type="tel" value={formData.ownerPhone} onChange={e => setFormData({...formData, ownerPhone: e.target.value})} placeholder="(00) 00000-0000" className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3.5 pl-12 pr-4 text-sm font-bold text-slate-900 outline-none focus:ring-2 focus:ring-[#d4a853]/20" />
                </div>
              </div>

              <div className="space-y-1 md:col-span-2">
                <label className="text-[10px] font-bold text-slate-500 uppercase ml-1">Classificação da Listagem</label>
                <div className="relative">
                  <Tag className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <select 
                    value={formData.listingType}
                    onChange={e => setFormData({...formData, listingType: e.target.value})}
                    className="w-full bg-white border border-slate-200 rounded-xl py-3.5 pl-12 pr-4 text-sm font-bold text-slate-900 outline-none focus:ring-2 focus:ring-[#d4a853]/20 shadow-sm"
                  >
                    {LISTING_TYPES.map(lt => <option key={lt} value={lt}>{lt}</option>)}
                  </select>
                </div>
              </div>
            </div>
          </section>

          <section className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-[#d4a853] uppercase ml-1">Tipo de Imóvel</label>
              <div className="relative">
                <Layers className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#d4a853]" />
                <select 
                  value={formData.type}
                  onChange={e => {
                    const newType = e.target.value;
                    const newCode = generateCode(newType);
                    setFormData({...formData, type: newType, code: newCode});
                  }}
                  className="w-full bg-white border border-[#d4a853]/20 rounded-xl py-3.5 pl-12 pr-4 text-sm font-bold text-slate-900 outline-none focus:ring-2 focus:ring-[#d4a853]/20 shadow-sm"
                >
                  {availableTypes.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-[#d4a853] uppercase ml-1">Identificador REF (Auto)</label>
              <div className="relative">
                <Hash className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#d4a853]" />
                <input type="text" readOnly value={formData.code} className="w-full bg-slate-100 border border-slate-200 rounded-xl py-3.5 pl-12 pr-4 text-sm font-black text-slate-900 outline-none" />
              </div>
            </div>

            <div className="space-y-1 md:col-span-2">
              <label className="text-[10px] font-bold text-slate-500 uppercase ml-1">Corretor Captador</label>
              <div className="relative">
                <UserCheck className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <select 
                  value={formData.brokerId}
                  onChange={e => setFormData({...formData, brokerId: e.target.value})}
                  className="w-full bg-white border border-slate-200 rounded-xl py-3.5 pl-12 pr-4 text-sm font-bold text-slate-900 outline-none focus:ring-2 focus:ring-[#d4a853]/20 shadow-sm"
                >
                  {brokers.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                </select>
              </div>
            </div>

            <div className="space-y-1 md:col-span-2">
              <label className="text-[10px] font-bold text-slate-500 uppercase ml-1">Nome do Empreendimento</label>
              <div className="relative">
                <LayoutPanelTop className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#d4a853]" />
                <input 
                  type="text" 
                  value={formData.projectName} 
                  onChange={e => setFormData({...formData, projectName: e.target.value})} 
                  placeholder="Nome do Condomínio ou Edifício" 
                  className="w-full bg-white border border-[#d4a853]/20 rounded-xl py-3.5 pl-12 pr-4 text-sm font-bold text-slate-900 outline-none focus:ring-2 focus:ring-[#d4a853]/20 shadow-sm" 
                />
              </div>
            </div>

            <div className="space-y-1 md:col-span-2">
              <label className="text-[10px] font-bold text-slate-500 uppercase ml-1">Título Público do Anúncio</label>
              <input type="text" required value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} placeholder="Título persuasivo para portais" className="w-full bg-white border border-slate-200 rounded-xl py-3.5 px-4 text-sm font-bold text-slate-900 outline-none focus:ring-2 focus:ring-[#d4a853]/20 shadow-sm" />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-500 uppercase ml-1">Valor Venda (R$)</label>
              <div className="relative">
                <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-500" />
                <input type="text" value={displayPrice} onChange={e => handlePriceChange(e.target.value, setDisplayPrice, 'price')} className="w-full bg-white border border-slate-200 rounded-xl py-3.5 pl-12 pr-4 text-sm font-black text-slate-900 outline-none focus:ring-2 focus:ring-[#d4a853]/20 shadow-sm" />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-500 uppercase ml-1">Valor Locação (R$)</label>
              <div className="relative">
                <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-blue-500" />
                <input type="text" value={displayRentPrice} onChange={e => handlePriceChange(e.target.value, setDisplayRentPrice, 'rentPrice')} className="w-full bg-white border border-slate-200 rounded-xl py-3.5 pl-12 pr-4 text-sm font-black text-slate-900 outline-none focus:ring-2 focus:ring-[#d4a853]/20 shadow-sm" />
              </div>
            </div>

            <div className="space-y-1 md:col-span-2">
              <label className="text-[10px] font-bold text-slate-500 uppercase ml-1">Localização (Endereço)</label>
              <div className="relative">
                <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#d4a853]" />
                <input type="text" required value={formData.address} onChange={e => setFormData({...formData, address: e.target.value})} className="w-full bg-white border border-slate-200 rounded-xl py-3.5 pl-12 pr-4 text-sm font-bold text-slate-900 outline-none focus:ring-2 focus:ring-[#d4a853]/20 shadow-sm" />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 md:col-span-2">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase text-center block">m² Privativo</label>
                <input type="number" value={formData.area === undefined ? '' : formData.area} onChange={e => setFormData({...formData, area: e.target.value === '' ? undefined : Number(e.target.value)})} placeholder="0" className="w-full bg-white border border-slate-200 rounded-xl py-2.5 px-2 text-center text-sm font-black text-slate-900 outline-none shadow-sm" />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase text-center block">Suítes / WCs</label>
                <input type="number" value={formData.bathrooms === undefined ? '' : formData.bathrooms} onChange={e => setFormData({...formData, bathrooms: e.target.value === '' ? undefined : Number(e.target.value)})} placeholder="0" className="w-full bg-white border border-slate-200 rounded-xl py-2.5 px-2 text-center text-sm font-black text-slate-900 outline-none shadow-sm" />
              </div>
            </div>
          </section>

          <section className="p-6 bg-[#0a1120] rounded-[2.5rem] border border-white/5 space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-[11px] font-black uppercase tracking-[0.2em] text-[#d4a853] flex items-center">
                <Sparkles className="w-4 h-4 mr-2" />
                Marca D'água (Automação Visual)
              </h3>
              <label className="relative inline-flex items-center cursor-pointer scale-90">
                <input type="checkbox" checked={formData.applyWatermark} onChange={e => setFormData({...formData, applyWatermark: e.target.checked})} className="sr-only peer" />
                <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#d4a853]"></div>
              </label>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="space-y-1">
                  <label className="text-[9px] font-bold text-slate-500 uppercase tracking-widest ml-1">Identificação por Texto</label>
                  <div className="relative">
                    <TypeIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#d4a853]" />
                    <input type="text" value={formData.watermarkText} onChange={e => setFormData({...formData, watermarkText: e.target.value})} className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-10 pr-4 text-xs font-bold text-white outline-none focus:ring-1 focus:ring-[#d4a853]" />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[9px] font-bold text-slate-500 uppercase tracking-widest ml-1">Logotipo Corporativo</label>
                  <button type="button" onClick={() => watermarkInputRef.current?.click()} className="w-full bg-white/5 border border-dashed border-white/20 rounded-xl py-3 flex items-center justify-center space-x-2 text-white/60 hover:text-white hover:border-[#d4a853] transition-all">
                    {formData.watermarkImage ? <ImageIcon className="w-4 h-4 text-[#d4a853]" /> : <UploadCloud className="w-4 h-4" />}
                    <span className="text-[10px] font-bold uppercase">{formData.watermarkImage ? 'Alterar Logo' : 'Upload PNG/JPG'}</span>
                  </button>
                  <input type="file" ref={watermarkInputRef} accept="image/*" onChange={handleWatermarkUpload} className="hidden" />
                </div>
              </div>

              <div className="space-y-4 bg-white/5 p-4 rounded-2xl border border-white/5 flex flex-col justify-center">
                 <div className="flex items-center justify-between mb-2">
                    <label className="text-[10px] font-bold text-[#d4a853] uppercase flex items-center">
                      <SlidersHorizontal className="w-3 h-3 mr-2" />
                      Nível de Transparência: {Math.round((formData.watermarkOpacity || 0.5) * 100)}%
                    </label>
                 </div>
                 <input 
                   type="range" min="0.1" max="1.0" step="0.05" 
                   value={formData.watermarkOpacity} 
                   onChange={e => setFormData({...formData, watermarkOpacity: parseFloat(e.target.value)})}
                   className="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-[#d4a853]"
                 />
                 <div className="mt-4 border-t border-white/5 pt-3">
                   {formData.watermarkImage && (
                     <div className="flex items-center space-x-3">
                        <img src={formData.watermarkImage} className="w-10 h-10 object-contain rounded-lg bg-white/10 p-1" style={{opacity: formData.watermarkOpacity}} />
                        <span className="text-[9px] text-slate-500 italic">Previsão da transparência aplicada.</span>
                     </div>
                   )}
                 </div>
              </div>
            </div>
          </section>

          <section className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-[11px] font-black uppercase tracking-[0.2em] text-slate-900 flex items-center">
                <ImageIcon className="w-4 h-4 mr-2 text-[#d4a853]" />
                Álbum de Mídia (Fotos do Imóvel)
              </h3>
              <button type="button" onClick={() => fileInputRef.current?.click()} className="text-[10px] font-black uppercase text-[#d4a853] bg-[#d4a853]/10 px-4 py-2 rounded-full border border-[#d4a853]/20 hover:bg-[#d4a853] hover:text-white transition-all">
                <Plus className="w-3.5 h-3.5 inline mr-1" /> Adicionar Fotos
              </button>
              <input type="file" ref={fileInputRef} multiple accept="image/*" onChange={handleImageUpload} className="hidden" />
            </div>

            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-3">
              {gallery.map((img, idx) => (
                <div key={idx} className="relative aspect-square rounded-2xl overflow-hidden border border-slate-200 group bg-slate-100 shadow-sm">
                  <img src={img} className="w-full h-full object-cover transition-transform group-hover:scale-110" />
                  <button type="button" onClick={() => removeImage(idx)} className="absolute top-1.5 right-1.5 bg-red-500 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-md">
                    <X className="w-3 h-3" />
                  </button>
                  {idx === 0 && <div className="absolute bottom-0 left-0 right-0 bg-emerald-500 text-white text-[8px] font-black uppercase text-center py-0.5">Capa do Anúncio</div>}
                </div>
              ))}
              <button type="button" onClick={() => fileInputRef.current?.click()} className="aspect-square rounded-2xl border-2 border-dashed border-slate-200 flex flex-col items-center justify-center text-slate-300 hover:text-[#d4a853] hover:border-[#d4a853] transition-all bg-slate-50/50">
                <Plus className="w-7 h-7 mb-1" />
                <span className="text-[9px] font-bold uppercase tracking-widest">Upload</span>
              </button>
            </div>
          </section>

          <button 
            type="submit" 
            disabled={isSubmitting}
            className={`w-full gold-gradient text-white py-5 rounded-3xl font-black uppercase tracking-widest text-sm shadow-xl shadow-yellow-900/20 hover:scale-[1.01] active:scale-95 transition-all mt-4 flex items-center justify-center space-x-3 ${isSubmitting ? 'opacity-70' : ''}`}
          >
            {isSubmitting ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
            <span>{isSubmitting ? 'Sincronizando...' : (propertyToEdit ? 'Atualizar Dados no Portfólio' : 'Consolidar Captação Vettus')}</span>
          </button>
        </form>
      </div>
    </div>
  );
};
