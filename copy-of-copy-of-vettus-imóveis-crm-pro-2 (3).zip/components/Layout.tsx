
import React, { useState, useRef, useEffect } from 'react';
import { 
  LayoutDashboard, 
  Home, 
  Users, 
  Bell, 
  Calendar, 
  LogOut, 
  Megaphone,
  Kanban,
  ShieldCheck,
  BadgeDollarSign,
  TableProperties,
  FileUp,
  Database
} from 'lucide-react';
import { Broker, AppView } from '../types.ts';

export const VettusLogo = ({ className = "w-20 h-20" }: { className?: string }) => (
  <div className={`relative ${className} flex items-center justify-center`}>
    <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-2xl">
      <defs>
        <linearGradient id="goldGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style={{ stopColor: '#d4a853', stopOpacity: 1 }} />
          <stop offset="50%" style={{ stopColor: '#f3d692', stopOpacity: 1 }} />
          <stop offset="100%" style={{ stopColor: '#b8860b', stopOpacity: 1 }} />
        </linearGradient>
      </defs>
      <path d="M15 25 L38 25 L50 65 L62 25 L85 25 L55 92 L45 92 Z" fill="url(#goldGradient)" />
      <g fill="#0f172a">
        <path d="M47 30 H53 V70 H47 Z" />
        <path d="M42 45 H46 V70 H42 Z" />
        <path d="M54 40 H58 V70 H54 Z" />
      </g>
      <line x1="50" y1="30" x2="50" y2="25" stroke="url(#goldGradient)" strokeWidth="0.5" />
    </svg>
  </div>
);

interface LayoutProps {
  children: React.ReactNode;
  currentView: string;
  onViewChange: (view: AppView) => void;
  currentUser: Broker;
  onLogout: () => void;
  pendingRemindersCount: number;
}

export const Layout: React.FC<LayoutProps> = ({ 
  children, 
  currentView, 
  onViewChange, 
  currentUser, 
  onLogout, 
  pendingRemindersCount
}) => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const allNavItems = [
    { id: 'dashboard' as AppView, icon: LayoutDashboard, label: 'Painel' },
    { id: 'lead_import' as AppView, icon: FileUp, label: 'Novo Lead' },
    { id: 'tasks' as AppView, icon: Kanban, label: 'Funil' },
    { id: 'properties' as AppView, icon: Home, label: 'Imóveis' },
    { id: 'clients' as AppView, icon: Users, label: 'Clientes' },
    { id: 'sales' as AppView, icon: BadgeDollarSign, label: 'Vendas' },
    { id: 'spreadsheets' as AppView, icon: TableProperties, label: 'Planilhas' },
    { id: 'marketing' as AppView, icon: Megaphone, label: 'Marketing' },
    { id: 'activities' as AppView, icon: Calendar, label: 'Agenda' },
    { id: 'reminders' as AppView, icon: Bell, label: 'Lembretes' },
    { id: 'brokers' as AppView, icon: ShieldCheck, label: 'Equipe' },
    { id: 'backup' as AppView, icon: Database, label: 'Backup' },
  ];

  const navItems = allNavItems.filter(item => {
    if ((item.id === 'brokers' || item.id === 'backup') && currentUser.role !== 'Admin') return false;
    if (!currentUser.permissions) return true;
    return currentUser.permissions.includes(item.id);
  });

  return (
    <div className="flex min-h-screen bg-slate-50">
      <aside className="w-64 bg-[#0a1120] text-white flex flex-col fixed inset-y-0 left-0 z-50">
        <div className="p-6 flex flex-col items-center border-b border-white/5">
          <VettusLogo className="w-20 h-20 mb-2" />
          <h1 className="text-lg font-extrabold tracking-widest text-[#d4a853] uppercase">VETTUS</h1>
        </div>
        
        <div className="px-4 py-6 space-y-4 flex-1 overflow-y-auto no-scrollbar">
          <div className="space-y-1">
            <h3 className="text-[9px] font-black text-slate-500 uppercase tracking-[0.2em] mb-3 ml-4">Navegação Principal</h3>
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => onViewChange(item.id)}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all ${
                  currentView === item.id ? 'bg-[#d4a853] text-white shadow-lg shadow-yellow-900/20' : 'text-slate-400 hover:bg-white/5 hover:text-white'
                }`}
              >
                <item.icon className="w-5 h-5" />
                <span className="font-semibold text-sm">{item.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="mt-auto p-4 border-t border-white/5">
          <div className="bg-white/5 p-4 rounded-2xl mb-4 border border-white/5">
             <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full gold-gradient flex items-center justify-center text-[10px] font-black">
                   {currentUser.name[0]}
                </div>
                <div className="flex-1 min-w-0">
                   <p className="text-xs font-bold truncate">{currentUser.name}</p>
                   <p className="text-[10px] text-slate-500 uppercase font-black">{currentUser.role}</p>
                </div>
             </div>
          </div>
          <button onClick={onLogout} className="w-full flex items-center space-x-3 px-4 py-3 text-slate-500 hover:text-red-400 transition-colors">
            <LogOut className="w-5 h-5" />
            <span className="text-sm font-bold uppercase tracking-widest">Sair da Rede</span>
          </button>
        </div>
      </aside>
      <main className="flex-1 ml-64 min-h-screen p-8 bg-[#f8fafc]">
        {children}
      </main>
    </div>
  );
};
