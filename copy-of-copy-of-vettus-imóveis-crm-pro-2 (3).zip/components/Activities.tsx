
import React, { useState, useMemo } from 'react';
import { 
  Phone, 
  Mail, 
  Users, 
  MapPin, 
  Calendar as CalendarIcon, 
  ChevronLeft, 
  ChevronRight, 
  Plus, 
  Clock, 
  X, 
  Bell, 
  CheckCircle, 
  LayoutList, 
  CalendarDays,
  StickyNote,
  Star
} from 'lucide-react';
import { Activity, Broker, Reminder, Client } from '../types';

interface ActivityViewProps {
  activities: Activity[];
  onAddActivity: (activity: Activity) => void;
  onAddReminder: (reminder: Reminder) => void;
  currentUser: Broker;
  clients: Client[];
}

export const ActivityView: React.FC<ActivityViewProps> = ({ 
  activities, 
  onAddActivity, 
  onAddReminder, 
  currentUser,
  clients 
}) => {
  const [viewMode, setViewMode] = useState<'calendar' | 'timeline'>('calendar');
  const [currentDate, setCurrentDate] = useState(new Date());
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedDay, setSelectedDay] = useState<number | null>(null);

  const [formData, setFormData] = useState({
    type: 'Call' as const,
    clientName: '',
    description: '',
    time: '10:00',
    createReminder: true,
    priority: 'Medium' as const
  });

  const daysInMonth = (year: number, month: number) => new Date(year, month + 1, 0).getDate();
  const firstDayOfMonth = (year: number, month: number) => new Date(year, month, 1).getDay();

  const monthName = useMemo(() => {
    return currentDate.toLocaleString('pt-BR', { month: 'long', year: 'numeric' });
  }, [currentDate]);

  const calendarDays = useMemo(() => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const days = daysInMonth(year, month);
    const firstDay = firstDayOfMonth(year, month);
    const totalSlots = 42;
    
    const slots = [];
    for (let i = 0; i < firstDay; i++) slots.push({ day: null, current: false });
    for (let i = 1; i <= days; i++) slots.push({ day: i, current: true });
    while (slots.length < totalSlots) slots.push({ day: null, current: false });
    
    return slots;
  }, [currentDate]);

  const handlePrevMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1));
  const handleNextMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1));

  const getActivitiesForDay = (day: number | null) => {
    if (!day) return [];
    const dateStr = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    return activities.filter(a => a.date === dateStr);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const dayToUse = selectedDay || new Date().getDate();
    const dateStr = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${String(dayToUse).padStart(2, '0')}`;
    
    const newActivity: Activity = {
      id: Math.random().toString(36).substr(2, 9),
      brokerId: currentUser.id,
      type: formData.type,
      clientName: formData.clientName || 'Cliente Geral',
      description: formData.description,
      date: dateStr,
      time: formData.time,
      updatedAt: new Date().toISOString()
    };

    onAddActivity(newActivity);

    if (formData.createReminder) {
      const newReminder: Reminder = {
        id: Math.random().toString(36).substr(2, 9),
        brokerId: currentUser.id,
        title: `${formData.type}: ${formData.description}`,
        dueDate: dateStr,
        priority: formData.priority,
        completed: false,
        updatedAt: new Date().toISOString()
      };
      onAddReminder(newReminder);
    }

    setIsModalOpen(false);
    setFormData({ type: 'Call', clientName: '', description: '', time: '10:00', createReminder: true, priority: 'Medium' });
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Agenda & Atividades</h1>
          <p className="text-slate-500">Cronograma sincronizado com sua carteira VIP.</p>
        </div>
        
        <div className="flex items-center space-x-3">
          <div className="bg-slate-100 p-1 rounded-xl flex items-center">
            <button 
              onClick={() => setViewMode('calendar')}
              className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center space-x-2 transition-all ${viewMode === 'calendar' ? 'bg-white shadow-sm text-slate-900' : 'text-slate-500'}`}
            >
              <CalendarDays className="w-4 h-4" />
              <span>Calendário</span>
            </button>
            <button 
              onClick={() => setViewMode('timeline')}
              className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center space-x-2 transition-all ${viewMode === 'timeline' ? 'bg-white shadow-sm text-slate-900' : 'text-slate-500'}`}
            >
              <LayoutList className="w-4 h-4" />
              <span>Timeline</span>
            </button>
          </div>
          <button 
            onClick={() => { setSelectedDay(null); setIsModalOpen(true); }}
            className="gold-gradient text-white px-5 py-2.5 rounded-xl text-xs font-bold flex items-center space-x-2 shadow-lg hover:scale-105 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Agendar</span>
          </button>
        </div>
      </div>

      {viewMode === 'calendar' ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 bg-white rounded-[2.5rem] border border-slate-100 shadow-xl overflow-hidden flex flex-col">
            <div className="navy-gradient p-8 flex items-center justify-between text-white">
              <h2 className="text-xl font-bold uppercase tracking-widest flex items-center">
                <CalendarIcon className="w-5 h-5 mr-3 text-[#d4a853]" />
                {monthName}
              </h2>
              <div className="flex items-center space-x-2">
                <button onClick={handlePrevMonth} className="p-2 hover:bg-white/10 rounded-full transition-colors"><ChevronLeft className="w-5 h-5" /></button>
                <button onClick={() => setCurrentDate(new Date())} className="px-4 py-1.5 bg-white/10 hover:bg-white/20 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-colors">Hoje</button>
                <button onClick={handleNextMonth} className="p-2 hover:bg-white/10 rounded-full transition-colors"><ChevronRight className="w-5 h-5" /></button>
              </div>
            </div>
            
            <div className="p-8 grid grid-cols-7 gap-px bg-slate-100">
              {['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].map(day => (
                <div key={day} className="bg-white py-4 text-center">
                  <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">{day}</span>
                </div>
              ))}
              
              {calendarDays.map((slot, idx) => {
                const dayActs = getActivitiesForDay(slot.day);
                const isToday = slot.day === new Date().getDate() && 
                                currentDate.getMonth() === new Date().getMonth() && 
                                currentDate.getFullYear() === new Date().getFullYear();
                
                return (
                  <div 
                    key={idx} 
                    onClick={() => { if(slot.day) { setSelectedDay(slot.day); setIsModalOpen(true); } }}
                    className={`bg-white h-32 p-3 relative group transition-all cursor-pointer hover:bg-slate-50 ${!slot.current ? 'bg-slate-50/50' : ''}`}
                  >
                    <span className={`text-xs font-bold ${isToday ? 'bg-[#d4a853] text-white w-6 h-6 rounded-full flex items-center justify-center shadow-md' : slot.current ? 'text-slate-900' : 'text-slate-300'}`}>
                      {slot.day}
                    </span>
                    
                    <div className="mt-2 space-y-1">
                      {dayActs.slice(0, 2).map(act => (
                        <div key={act.id} className="bg-slate-100 rounded-md p-1 border-l-2 border-[#d4a853] overflow-hidden">
                          <p className="text-[9px] font-bold text-slate-700 truncate">{act.description}</p>
                        </div>
                      ))}
                      {dayActs.length > 2 && (
                        <p className="text-[8px] font-bold text-[#d4a853] uppercase">+{dayActs.length - 2} mais</p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm">
              <h3 className="text-sm font-black uppercase tracking-widest text-slate-900 mb-6 flex items-center">
                <Star className="w-4 h-4 mr-2 text-[#d4a853]" />
                Atividades em Destaque
              </h3>
              <div className="space-y-4">
                {activities.slice(0, 5).map(act => (
                  <div key={act.id} className="flex items-start space-x-4 p-4 rounded-2xl hover:bg-slate-50 transition-colors border border-transparent hover:border-slate-100 group">
                    <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center group-hover:bg-[#d4a853] group-hover:text-white transition-all">
                      {act.type === 'Call' && <Phone className="w-4 h-4" />}
                      {act.type === 'Email' && <Mail className="w-4 h-4" />}
                      {act.type === 'Viewing' && <MapPin className="w-4 h-4" />}
                      {act.type === 'Meeting' && <Users className="w-4 h-4" />}
                    </div>
                    <div>
                      <p className="text-xs font-bold text-slate-900">{act.description}</p>
                      <p className="text-[10px] text-slate-400 mt-1 uppercase tracking-widest">{new Date(act.date).toLocaleDateString('pt-BR')}</p>
                    </div>
                  </div>
                ))}
                {activities.length === 0 && (
                  <div className="text-center py-10">
                    <StickyNote className="w-10 h-10 text-slate-200 mx-auto mb-2" />
                    <p className="text-xs text-slate-400 italic">Sua agenda está livre.</p>
                  </div>
                )}
              </div>
            </div>

            <div className="gold-gradient p-8 rounded-[2rem] text-white shadow-xl shadow-yellow-900/20">
               <div className="flex items-center space-x-3 mb-4">
                  <Bell className="w-6 h-6 animate-swing" />
                  <h4 className="text-lg font-bold">Lembretes Ativos</h4>
               </div>
               <p className="text-xs text-white/80 leading-relaxed mb-6">Integre suas notas diretamente com a central de notificações para nunca perder uma negociação.</p>
               <div className="bg-white/10 p-4 rounded-xl backdrop-blur-sm border border-white/10">
                  <p className="text-[10px] font-bold uppercase tracking-widest opacity-60 mb-2">Resumo da Semana</p>
                  <p className="text-2xl font-black">{activities.length} Agendamentos</p>
               </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="max-w-4xl mx-auto space-y-8 no-scrollbar">
          <div className="relative space-y-8 before:absolute before:inset-0 before:ml-5 before:-translate-x-px before:h-full before:w-0.5 before:bg-gradient-to-b before:from-slate-200 before:via-slate-200 before:to-transparent">
            {activities.map((activity) => (
              <div key={activity.id} className="relative flex items-center group">
                <div className="flex items-center justify-center w-10 h-10 rounded-full border border-white bg-slate-900 text-white shadow-xl z-10 group-hover:scale-110 transition-transform">
                  {activity.type === 'Call' && <Phone className="w-4 h-4" />}
                  {activity.type === 'Email' && <Mail className="w-4 h-4" />}
                  {activity.type === 'Viewing' && <MapPin className="w-4 h-4" />}
                  {activity.type === 'Meeting' && <Users className="w-4 h-4" />}
                </div>
                <div className="ml-6 flex-1 p-6 rounded-3xl bg-white border border-slate-100 shadow-sm hover:shadow-xl hover:border-[#d4a853]/20 transition-all">
                  <div className="flex items-center justify-between space-x-2 mb-2">
                    <div className="font-bold text-slate-900">{activity.description}</div>
                    <div className="flex items-center text-[#d4a853]">
                       <Clock className="w-3.5 h-3.5 mr-1" />
                       <time className="font-bold text-xs uppercase tracking-tighter">{activity.time}</time>
                    </div>
                  </div>
                  <div className="text-slate-500 text-sm mb-4">
                    Com o lead <span className="font-bold text-slate-700">{activity.clientName}</span>
                  </div>
                  <div className="flex items-center text-[10px] text-slate-400 font-bold uppercase tracking-[0.2em] bg-slate-50 px-4 py-1.5 rounded-full w-fit">
                    <CalendarIcon className="w-3.5 h-3.5 mr-2" />
                    {new Date(activity.date).toLocaleDateString('pt-BR', { day: 'numeric', month: 'long', year: 'numeric' })}
                  </div>
                </div>
              </div>
            ))}
            {activities.length === 0 && (
              <div className="py-20 text-center text-slate-400">Nenhuma atividade registrada no seu cadastro.</div>
            )}
          </div>
        </div>
      )}

      {isModalOpen && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-[#0f172a]/70 backdrop-blur-md" onClick={() => setIsModalOpen(false)}></div>
          <div className="bg-white w-full max-w-lg rounded-[2.5rem] p-0 relative z-10 shadow-2xl animate-in zoom-in duration-300 overflow-hidden">
            <div className="navy-gradient p-8 text-white">
               <div className="flex items-center justify-between mb-2">
                  <div className="w-12 h-12 gold-gradient rounded-2xl flex items-center justify-center shadow-lg">
                    <Clock className="w-6 h-6" />
                  </div>
                  <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-white/10 rounded-full transition-colors"><X className="w-6 h-6 text-white" /></button>
               </div>
               <h2 className="text-2xl font-bold uppercase tracking-tight">Agendar Atividade</h2>
               <p className="text-slate-400 text-sm">Organize seu dia com precisão cirúrgica.</p>
            </div>

            <form onSubmit={handleSubmit} className="p-8 bg-slate-50 space-y-6">
               <div className="grid grid-cols-4 gap-2">
                  {[
                    { id: 'Call', icon: Phone, label: 'Call' },
                    { id: 'Meeting', icon: Users, label: 'Reunião' },
                    { id: 'Viewing', icon: MapPin, label: 'Visita' },
                    { id: 'Email', icon: Mail, label: 'E-mail' }
                  ].map(type => (
                    <button 
                      key={type.id}
                      type="button"
                      onClick={() => setFormData({...formData, type: type.id as any})}
                      className={`flex flex-col items-center justify-center p-3 rounded-2xl border transition-all ${formData.type === type.id ? 'bg-[#0f172a] text-white border-[#0f172a] shadow-lg' : 'bg-white border-slate-200 text-slate-400 hover:border-[#d4a853]'}`}
                    >
                      <type.icon className="w-5 h-5 mb-1" />
                      <span className="text-[9px] font-bold uppercase">{type.label}</span>
                    </button>
                  ))}
               </div>

               <div className="space-y-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Vincular a Cliente</label>
                    <select 
                      value={formData.clientName}
                      onChange={e => setFormData({...formData, clientName: e.target.value})}
                      className="w-full bg-white border border-slate-200 rounded-xl py-3.5 px-4 text-sm text-slate-900 outline-none font-bold shadow-sm"
                    >
                      <option value="">Nenhum (Atividade Interna)</option>
                      {clients.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Descrição do Agendamento</label>
                    <input 
                      type="text" required
                      value={formData.description}
                      onChange={e => setFormData({...formData, description: e.target.value})}
                      placeholder="Ex: Apresentação de Proposta Cobertura Jardins"
                      className="w-full bg-white border border-slate-200 rounded-xl py-3.5 px-4 text-sm text-slate-900 outline-none font-bold shadow-sm placeholder:text-slate-300"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                     <div className="space-y-1">
                        <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Horário</label>
                        <input 
                          type="time" required
                          value={formData.time}
                          onChange={e => setFormData({...formData, time: e.target.value})}
                          className="w-full bg-white border border-slate-200 rounded-xl py-3.5 px-4 text-sm text-slate-900 outline-none font-black shadow-sm"
                        />
                     </div>
                     <div className="space-y-1">
                        <label className="text-[10px] font-bold text-[#d4a853] uppercase tracking-widest ml-1">Prioridade</label>
                        <select 
                          value={formData.priority}
                          onChange={e => setFormData({...formData, priority: e.target.value as any})}
                          className="w-full bg-white border border-slate-200 rounded-xl py-3.5 px-4 text-sm text-slate-900 outline-none font-black shadow-sm"
                        >
                          <option value="High">Alta</option>
                          <option value="Medium">Média</option>
                          <option value="Low">Baixa</option>
                        </select>
                     </div>
                  </div>
               </div>

               <button type="submit" className="w-full gold-gradient text-white py-4 rounded-xl font-black text-sm uppercase tracking-widest shadow-xl shadow-yellow-900/20 hover:scale-[1.02] active:scale-95 transition-all">
                  Consolidar na Agenda VIP
               </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
