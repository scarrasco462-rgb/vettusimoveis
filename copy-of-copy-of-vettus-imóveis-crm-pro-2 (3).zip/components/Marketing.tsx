
import React, { useState } from 'react';
import { getAISuggestions } from '../services/gemini';
import { Megaphone, Users, Sparkles, Play, Plus, Zap } from 'lucide-react';
import { Campaign } from '../types';

interface MarketingViewProps {
  campaigns: Campaign[];
}

export const MarketingView: React.FC<MarketingViewProps> = ({ campaigns }) => {
  const [activeTab, setActiveTab] = useState<'campaigns' | 'flows' | 'ai'>('campaigns');
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiResult, setAiResult] = useState('');
  const [loading, setLoading] = useState(false);

  const handleGenerateAI = async () => {
    setLoading(true);
    const result = await getAISuggestions(`Como especialista de marketing da Vettus Imóveis, crie um texto curto e extremamente sofisticado para um e-mail VIP sobre: ${aiPrompt}. O tom deve ser de exclusividade total.`);
    setAiResult(result);
    setLoading(false);
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 uppercase tracking-tight">Marketing Elite</h1>
          <p className="text-slate-500">Suas campanhas personalizadas de alto impacto.</p>
        </div>
        <button className="gold-gradient text-white px-6 py-3 rounded-xl flex items-center space-x-2 text-sm font-bold shadow-lg">
          <Plus className="w-5 h-5" />
          <span>Criar Campanha VIP</span>
        </button>
      </div>

      <div className="flex space-x-6 border-b border-slate-200">
        <button 
          onClick={() => setActiveTab('campaigns')}
          className={`pb-4 px-2 text-sm font-bold transition-all ${activeTab === 'campaigns' ? 'text-[#d4a853] border-b-2 border-[#d4a853]' : 'text-slate-400 hover:text-slate-600'}`}
        >
          Minhas Campanhas
        </button>
        <button 
          onClick={() => setActiveTab('ai')}
          className={`pb-4 px-2 text-sm font-bold transition-all flex items-center space-x-2 ${activeTab === 'ai' ? 'text-[#d4a853] border-b-2 border-[#d4a853]' : 'text-slate-400 hover:text-slate-600'}`}
        >
          <Sparkles className="w-4 h-4" />
          <span>Copywriting AI</span>
        </button>
      </div>

      {activeTab === 'campaigns' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {campaigns.map(campaign => (
            <div key={campaign.id} className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-[#0f172a] text-[#d4a853] rounded-xl">
                  <Megaphone className="w-5 h-5" />
                </div>
                <span className={`px-2 py-1 rounded-full text-[8px] font-bold uppercase tracking-widest ${
                  campaign.status === 'Active' ? 'bg-green-50 text-green-600' : 'bg-slate-100 text-slate-500'
                }`}>
                  {campaign.status}
                </span>
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-1">{campaign.name}</h3>
              <p className="text-xs text-slate-400 mb-6 flex items-center">
                <Users className="w-3 h-3 mr-1" />
                Alvo: {campaign.segment}
              </p>
            </div>
          ))}
          {campaigns.length === 0 && (
            <div className="col-span-full py-20 text-center text-slate-400 italic">Nenhuma campanha registrada no seu cadastro.</div>
          )}
        </div>
      )}

      {activeTab === 'ai' && (
        <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-xl max-w-3xl mx-auto">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-12 h-12 gold-gradient rounded-2xl flex items-center justify-center">
              <Sparkles className="text-white w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-900">Vettus Content Creator</h2>
              <p className="text-sm text-slate-500">IA treinada para o mercado imobiliário premium.</p>
            </div>
          </div>
          
          <div className="space-y-4">
            <textarea 
              value={aiPrompt}
              onChange={(e) => setAiPrompt(e.target.value)}
              placeholder="Ex: Lançamento de mansão cinematográfica com heliponto em Alphaville..."
              className="w-full h-32 p-4 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-[#d4a853]/30 transition-all text-slate-700"
            />
            <button 
              onClick={handleGenerateAI}
              disabled={loading || !aiPrompt}
              className="w-full gold-gradient text-white py-4 rounded-xl font-bold flex items-center justify-center space-x-2 disabled:opacity-50"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
              ) : (
                <>
                  <Zap className="w-5 h-5" />
                  <span>Gerar Copy Premium Vettus</span>
                </>
              )}
            </button>
          </div>

          {aiResult && (
            <div className="mt-8 p-6 bg-slate-900 text-slate-100 rounded-2xl relative animate-in slide-in-from-bottom-4 duration-500 border-l-4 border-[#d4a853]">
              <div className="whitespace-pre-wrap leading-relaxed text-sm italic opacity-90 pt-4">
                {aiResult}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
