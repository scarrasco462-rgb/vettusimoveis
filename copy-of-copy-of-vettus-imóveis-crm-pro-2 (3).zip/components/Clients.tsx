import React, { useState, useEffect } from 'react';
import { 
  Mail, 
  Phone, 
  UserPlus, 
  X, 
  User, 
  DollarSign, 
  Briefcase, 
  CheckCircle, 
  MessageSquare, 
  Clock, 
  MapPin, 
  History, 
  Plus, 
  Tag,
  ShieldCheck,
  Check,
  Sparkles,
  ArrowRightLeft,
  Zap,
  Star,
  UserCheck,
  CalendarDays,
  AlertCircle,
  ArrowLeftRight,
  ShieldAlert,
  Calendar,
  MessageCircle,
  PhoneForwarded,
  Save,
  Award,
  Hash,
  Building2,
  FileText,
  FileUp,
  Pencil,
  Trash2,
  Globe,
  FileSpreadsheet
} from 'lucide-react';
import { Client, ClientStatus, Broker, Activity, Property, Commission, PropertyStatus } from '../types.ts';

interface ClientViewProps {
  clients: Client[];
  activities: Activity[];
  properties: Property[];
  onAddClient: (client: Client) => void;
  onUpdateClient: (client: Client) => void;
  onDeleteClient: (id: string) => void;
  onEditClient: (client: Client) => void;
  onAddActivity: (activity: Activity) => void;
  onAddSale: (sale: Commission) => void;
  onUpdateProperty: (property: Property) => void;
  currentUser: Broker;
  brokers: Broker[]; 
  onOpenAddModal?: () => void;
  onOpenImport?: () => void;
}

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 2,
  }).format(value);
};

export const ClientView: React.FC<ClientViewProps> = ({ 
  clients, 
  activities, 
  properties = [],
  onAddClient, 
  onUpdateClient,
  onDeleteClient,
  onEditClient,
  onAddActivity,
  onAddSale,
  onUpdateProperty,
  currentUser,
  brokers,
  onOpenAddModal,
  onOpenImport
}) => {
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [showHistoryModal, setShowHistoryModal] = useState(false);
  const [showSaleModal, setShowSaleModal] = useState(false);
  
  const [newActivityDesc, setNewActivityDesc] = useState('');
  const [activityType, setActivityType] = useState<'Call' | 'Meeting' | 'Viewing' | 'Email' | 'WhatsApp'>('Call');
  const [nextStepDate, setNextStepDate] = useState('');
  const [nextStepType, setNextStepType] = useState<'Call' | 'Meeting' | 'Viewing' | 'Email' | 'WhatsApp' | 'Call_Back'>('Call');
  const [isTransferring, setIsTransferring] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date().toLocaleTimeString('pt-BR'));

  const [saleData, setSaleData] = useState({
    propertyTitle: '',
    propertyCode: '',
    unitNumber: '',
    amount: 0,
    commissionAmount: 0,
    date: new Date().toISOString().split('T')[0]
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date().toLocaleTimeString('pt-BR'));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleOpenHistory = (client: Client) => {
    setSelectedClient(client);
    setNextStepDate(client.nextActivityDate || '');
    setNextStepType(client.nextActivityType || 'Call');
    setShowHistoryModal(true);
  };

  const handleUpdateClientField = (field: keyof Client, value: any) => {
    if (!selectedClient) return;
    const updatedClient = { ...selectedClient, [field]: value };
    onUpdateClient(updatedClient);
    setSelectedClient(updatedClient);
  };

  const handleStatusChange = (newStatus: ClientStatus) => {
    if (!selectedClient) return;
    
    if (newStatus === ClientStatus.WON) {
      setSaleData({
        propertyTitle: '',
        propertyCode: '',
        unitNumber: '',
        amount: 0,
        commissionAmount: 0,
        date: new Date().toISOString().split('T')[0]
      });
      setShowSaleModal(true);
      return;
    }

    handleUpdateClientField('status', newStatus);

    const statusActivity: Activity = {
      id: Math.random().toString(36).substr(2, 9),
      brokerId: currentUser.id,
      brokerName: currentUser.name,
      type: 'Email',
      clientName: selectedClient.name,
      description: `Status alterado para: ${newStatus}`,
      date: new Date().toISOString().split('T')[0],
      time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      updatedAt: new Date().toISOString()
    };
    onAddActivity(statusActivity);
  };

  const handleAddActivityRecord = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedClient || !newActivityDesc.trim()) return;

    const now = new Date();
    const exactTime = now.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

    const newActivity: Activity = {
      id: Math.random().toString(36).substr(2, 9),
      brokerId: currentUser.id,
      brokerName: currentUser.name,
      type: activityType,
      clientName: selectedClient.name,
      description: newActivityDesc,
      date: now.toISOString().split('T')[0],
      time: exactTime,
      updatedAt: now.toISOString()
    };

    onAddActivity(newActivity);
    
    const updatedClient: Client = {
      ...selectedClient,
      nextActivityDate: nextStepDate,
      nextActivityType: nextStepType,
      updatedAt: now.toISOString()
    };
    onUpdateClient(updatedClient);
    setSelectedClient(updatedClient);

    setNewActivityDesc('');
  };

  const handleConfirmSale = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedClient || !saleData.propertyTitle) return;

    const now = new Date();

    const newSale: Commission = {
      id: Math.random().toString(36).substr(2, 9),
      brokerId: selectedClient.brokerId,
      propertyTitle: saleData.propertyTitle,
      propertyCode: saleData.propertyCode,
      unitNumber: saleData.unitNumber,
      salePrice: Number(saleData.amount), 
      amount: Number(saleData.commissionAmount), 
      status: 'Pending',
      date: saleData.date,
      clientName: selectedClient.name,
      updatedAt: now.toISOString()
    };

    onAddSale(newSale);

    const updatedClient: Client = {
      ...selectedClient,
      status: ClientStatus.WON,
      updatedAt: now.toISOString()
    };
    onUpdateClient(updatedClient);
    setSelectedClient(updatedClient);

    const existingProperty = properties.find(p => p.code === saleData.propertyCode);
    if (existingProperty) {
      onUpdateProperty({
        ...existingProperty,
        status: PropertyStatus.SOLD,
        updatedAt: now.toISOString()
      });
    }

    onAddActivity({
      id: Math.random().toString(36).substr(2, 9),
      brokerId: currentUser.id,
      brokerName: currentUser.name,
      type: 'Meeting',
      clientName: selectedClient.name,
      description: `🎉 VENDA CONCLUÍDA! Imóvel: ${saleData.propertyTitle} (REF: ${saleData.propertyCode}) - Valor: ${formatCurrency(saleData.amount)}`,
      date: now.toISOString().split('T')[0],
      time: now.toLocaleTimeString('pt-BR'),
      updatedAt: now.toISOString()
    });

    setShowSaleModal(false);
  };

  const handleTransfer = (newBrokerId: string) => {
    if (!selectedClient) return;
    const newBroker = brokers.find(b => b.id === newBrokerId);
    if (!newBroker) return;

    if (confirm(`Tem certeza que deseja transferir o lead ${selectedClient.name} para o corretor ${newBroker.name}?`)) {
      setIsTransferring(true);
      const oldBrokerName = selectedClient.assignedAgent;
      const now = new Date();
      
      const updatedClient: Client = {
        ...selectedClient,
        brokerId: newBrokerId,
        assignedAgent: newBroker.name,
        updatedAt: now.toISOString()
      };

      onUpdateClient(updatedClient);
      
      const transferActivity: Activity = {
        id: Math.random().toString(36).substr(2, 9),
        brokerId: currentUser.id,
        brokerName: currentUser.name,
        type: 'Meeting',
        clientName: selectedClient.name,
        description: `Lead transferido de ${oldBrokerName} para ${newBroker.name} por ${currentUser.name}`,
        date: now.toISOString().split('T')[0],
        time: now.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        updatedAt: now.toISOString()
      };
      
      onAddActivity(transferActivity);
      setSelectedClient(updatedClient);
      
      setTimeout(() => {
        setIsTransferring(false);
      }, 500);
    }
  };

  const handleDelete = (id: string, name: string) => {
    if (currentUser.role !== 'Admin') return;
    if (confirm(`DESEJA REALMENTE EXCLUIR O CLIENTE ${name.toUpperCase()}? Esta ação removerá o lead permanentemente da rede.`)) {
      onDeleteClient(id);
      if (selectedClient?.id === id) {
        setShowHistoryModal(false);
        setSelectedClient(null);
      }
    }
  };

  const getStatusColor = (status: ClientStatus) => {
    switch(status) {
      case ClientStatus.FIRST_CONTACT: return 'bg-blue-50 text-blue-600 border-blue-100';
      case ClientStatus.HOT: return 'bg-red-50 text-red-600 border-red-100';
      case ClientStatus.WARM: return 'bg-orange-50 text-orange-600 border-orange-100';
      case ClientStatus.COLD: return 'bg-green-50 text-green-600 border-green-100';
      case ClientStatus.WON: return 'gold-gradient text-white border-transparent';
      default: return 'bg-slate-50 text-slate-600 border-slate-100';
    }
  };

  const getActivityIcon = (type: string) => {
    switch(type) {
      case 'Call': return <Phone className="w-4 h-4" />;
      case 'Call_Back': return <PhoneForwarded className="w-4 h-4" />;
      case 'WhatsApp': return <MessageCircle className="w-4 h-4" />;
      case 'Email': return <Mail className="w-4 h-4" />;
      case 'Meeting':
      case 'Viewing': return <MapPin className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const isActivityExpired = (dateString?: string) => {
    if (!dateString) return false;
    const today = new Date().toISOString().split('T')[0];
    return dateString < today;
  };

  const canAction = (client: Client) => {
    return currentUser.role === 'Admin' || client.brokerId === currentUser.id;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Carteira de Clientes</h1>
          <p className="text-slate-500">Gestão de leads e relacionamentos de alto padrão.</p>
        </div>
        <div className="flex items-center space-x-3">
          <button 
            onClick={onOpenImport}
            className="bg-white border border-[#d4a853]/30 text-[#d4a853] px-6 py-3 rounded-xl flex items-center space-x-2 text-sm font-bold shadow-sm hover:bg-slate-50 transition-all"
          >
            <FileSpreadsheet className="w-5 h-5" />
            <span>Importar Planilha</span>
          </button>
          <button 
            onClick={onOpenAddModal}
            className="gold-gradient text-white px-6 py-3 rounded-xl flex items-center space-x-2 text-sm font-bold shadow-lg shadow-yellow-600/20 hover:scale-105 active:scale-95 transition-all"
          >
            <UserPlus className="w-5 h-5" />
            <span>Cadastro de Cliente</span>
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50 text-slate-400 text-xs font-bold uppercase tracking-wider">
                <th className="px-8 py-4">Cliente</th>
                <th className="px-8 py-4">Status</th>
                <th className="px-8 py-4">Follow-up</th>
                <th className="px-8 py-4">Orçamento</th>
                <th className="px-8 py-4 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {clients.map((client) => {
                const expired = isActivityExpired(client.nextActivityDate);
                const authorized = canAction(client);
                return (
                  <tr key={client.id} className="hover:bg-slate-50/50 transition-colors group">
                    <td className="px-8 py-6">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center font-bold text-slate-600 border border-slate-200">
                          {client.name[0]}
                        </div>
                        <div>
                          <button onClick={() => handleOpenHistory(client)} className="font-bold text-slate-900 hover:text-[#d4a853] transition-colors text-left">
                            {client.name}
                          </button>
                          <p className="text-xs text-slate-400">{client.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest ${getStatusColor(client.status)}`}>
                        {client.status}
                      </span>
                    </td>
                    <td className="px-8 py-6">
                      {client.nextActivityDate ? (
                        <div className={`flex items-center space-x-2 ${expired ? 'text-red-500' : 'text-slate-500'}`}>
                          {getActivityIcon(client.nextActivityType || 'Call')}
                          <span className={`text-xs font-bold ${expired ? 'animate-pulse' : ''}`}>
                            {new Date(client.nextActivityDate).toLocaleDateString('pt-BR')}
                          </span>
                        </div>
                      ) : (
                        <span className="text-[10px] text-slate-300 italic">Agendamento Livre</span>
                      )}
                    </td>
                    <td className="px-8 py-6">
                      <p className="text-sm font-bold text-slate-900">{formatCurrency(client.budget)}</p>
                    </td>
                    <td className="px-8 py-6 text-right">
                      <div className="flex items-center justify-end space-x-2">
                        {authorized && (
                          <button 
                            onClick={() => onEditClient(client)}
                            className="p-2 bg-slate-50 text-slate-400 border border-slate-100 rounded-lg hover:bg-blue-50 hover:text-blue-600 transition-all"
                            title="Editar Dados"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                        )}
                        {currentUser.role === 'Admin' && (
                          <button 
                            onClick={() => handleDelete(client.id, client.name)}
                            className="p-2 bg-slate-50 text-slate-400 border border-slate-100 rounded-lg hover:bg-red-50 hover:text-red-600 transition-all"
                            title="Excluir Cliente"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                        <button 
                          onClick={() => handleOpenHistory(client)}
                          className={`p-2 rounded-lg transition-all ${expired ? 'bg-red-50 text-red-500 shadow-sm' : 'bg-slate-50 text-slate-600 hover:bg-[#d4a853] hover:text-white'}`}
                        >
                          <History className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {showHistoryModal && selectedClient && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-[#0f172a]/70 backdrop-blur-md" onClick={() => setShowHistoryModal(false)}></div>
          <div className="bg-white w-full max-w-3xl rounded-[2.5rem] p-0 relative z-10 shadow-2xl animate-in zoom-in duration-300 overflow-hidden flex flex-col max-h-[90vh]">
            
            <div className="navy-gradient p-8 text-white shrink-0">
               <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                     <div className="w-16 h-16 rounded-2xl gold-gradient flex items-center justify-center text-2xl font-bold shadow-lg">
                        {selectedClient.name[0]}
                     </div>
                     <div>
                        <div className="flex items-center space-x-3">
                           <h2 className="text-2xl font-bold text-white">{selectedClient.name}</h2>
                           <div className="bg-white/10 px-3 py-1 rounded-full flex items-center space-x-1.5 border border-white/5">
                              <Globe className="w-3 h-3 text-[#d4a853]" />
                              <span className="text-[9px] font-black uppercase tracking-widest text-[#d4a853]">Histórico Global Liberado</span>
                           </div>
                        </div>
                        <div className="flex flex-col md:flex-row md:items-center md:space-x-6 mt-2">
                           <p className="text-slate-300 text-sm flex items-center">
                              <ShieldCheck className="w-4 h-4 mr-2 text-green-400" />
                              Lead Verificado
                           </p>
                           <p className="text-[#d4a853] text-sm font-black flex items-center bg-white/5 px-3 py-1 rounded-lg border border-white/5">
                              <Phone className="w-3.5 h-3.5 mr-2" />
                              CONTATO: {selectedClient.phone}
                           </p>
                        </div>
                     </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    {canAction(selectedClient) && (
                        <button 
                          onClick={() => onEditClient(selectedClient)}
                          className="p-3 bg-white/10 hover:bg-[#d4a853] rounded-xl text-white transition-all group"
                          title="Editar Cadastro"
                        >
                            <Pencil className="w-5 h-5 group-hover:scale-110" />
                        </button>
                    )}
                    <button onClick={() => setShowHistoryModal(false)} className="p-3 hover:bg-white/10 rounded-xl transition-colors text-white">
                        <X className="w-7 h-7" />
                    </button>
                  </div>
               </div>
            </div>

            <div className="p-8 overflow-y-auto no-scrollbar bg-white flex-1 space-y-10">
               
               <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-slate-50 p-6 rounded-3xl border border-slate-100">
                    <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-4 flex items-center">
                       <Zap className="w-3 h-3 mr-2 text-[#d4a853]" />
                       Qualificação do Lead
                    </h4>
                    <div className="grid grid-cols-2 gap-2">
                       {[ClientStatus.FIRST_CONTACT, ClientStatus.WARM, ClientStatus.HOT, ClientStatus.COLD].map(st => (
                         <button 
                           key={st} onClick={() => handleStatusChange(st)}
                           className={`py-2.5 rounded-xl text-[10px] font-bold uppercase tracking-widest border transition-all ${selectedClient.status === st ? 'bg-slate-900 text-white border-slate-900 shadow-lg' : 'bg-white text-slate-500 border-slate-200 hover:border-[#d4a853]'}`}
                         >
                           {st}
                         </button>
                       ))}
                       <button 
                         onClick={() => handleStatusChange(ClientStatus.WON)}
                         className={`col-span-2 py-3 rounded-xl text-[11px] font-black uppercase tracking-widest transition-all flex items-center justify-center space-x-2 border-2 ${selectedClient.status === ClientStatus.WON ? 'gold-gradient text-white border-transparent shadow-lg' : 'bg-emerald-50 text-emerald-600 border-emerald-100 hover:gold-gradient hover:text-white'}`}
                       >
                         <Award className="w-4 h-4" />
                         <span>Ganho (Fechar Venda)</span>
                       </button>
                    </div>
                  </div>

                  <div className="bg-white p-6 rounded-3xl border border-slate-100 flex flex-col justify-center">
                    <div className="flex items-center space-x-4 mb-4">
                       <div className="w-12 h-12 rounded-full gold-gradient flex items-center justify-center shadow-md">
                          <UserCheck className="w-6 h-6 text-white" />
                       </div>
                       <div>
                          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Agente Responsável</p>
                          <p className="text-lg font-bold text-slate-900">{selectedClient.assignedAgent}</p>
                       </div>
                    </div>
                    {currentUser.role === 'Admin' && (
                      <div className="mt-2">
                         <select 
                           disabled={isTransferring}
                           onChange={(e) => handleTransfer(e.target.value)}
                           className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-[10px] font-bold uppercase tracking-widest outline-none focus:ring-2 focus:ring-[#d4a853]/50 disabled:opacity-50 text-slate-900"
                         >
                           <option value="">🔄 Transferir Lead</option>
                           {brokers.filter(b => b.id !== selectedClient.brokerId).map(b => (
                             <option key={b.id} value={b.id}>{b.name}</option>
                           ))}
                         </select>
                      </div>
                    )}
                  </div>
               </div>

               <div className="bg-slate-50 p-8 rounded-[2.5rem] border border-slate-100 shadow-sm space-y-6">
                  <div className="flex items-center justify-between">
                    <h3 className="text-[11px] font-black uppercase tracking-[0.2em] text-[#d4a853] flex items-center">
                       <MessageSquare className="w-4 h-4 mr-2" />
                       Novo Log de Atendimento
                    </h3>
                    <div className="flex items-center text-[10px] font-black text-slate-400 uppercase tracking-widest bg-white px-3 py-1 rounded-full border border-slate-200 shadow-sm">
                       <Clock className="w-3 h-3 mr-2 text-[#d4a853]" />
                       {currentTime}
                    </div>
                  </div>
                  
                  <div className="space-y-5">
                     <div className="flex flex-col md:flex-row gap-3">
                        <select 
                          value={activityType} 
                          onChange={e => setActivityType(e.target.value as any)} 
                          className="md:w-40 bg-white border border-slate-200 rounded-2xl px-4 py-3 text-xs font-bold outline-none shadow-sm text-slate-900 focus:border-[#d4a853] transition-colors"
                        >
                           <option value="Call">📞 Ligação</option>
                           <option value="WhatsApp">💬 WhatsApp</option>
                           <option value="Email">📧 E-mail</option>
                           <option value="Meeting">🏠 Visita</option>
                        </select>
                        <input 
                           type="text" required value={newActivityDesc} onChange={e => setNewActivityDesc(e.target.value)}
                           placeholder="O que foi negociado hoje? Descreva aqui..." 
                           className="flex-1 bg-white border border-slate-200 rounded-2xl py-3 px-5 text-sm outline-none focus:ring-2 focus:ring-[#d4a853]/30 shadow-sm text-slate-900 placeholder:text-slate-400"
                        />
                     </div>

                     <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-white/50 p-5 rounded-2xl border border-white">
                        <div className="space-y-2">
                           <label className="text-[9px] font-black uppercase text-slate-400 tracking-widest ml-1">Próximo Passo (Follow-up)</label>
                           <select 
                             value={nextStepType} 
                             onChange={e => setNextStepType(e.target.value as any)}
                             className="w-full bg-white border border-slate-200 rounded-xl py-3 px-4 text-xs font-bold outline-none shadow-sm text-slate-900 focus:border-[#d4a853] transition-colors"
                           >
                              <option value="Call_Back">Retorno de Ligação</option>
                              <option value="WhatsApp">Enviar WhatsApp</option>
                              <option value="Email">Enviar Proposta/E-mail</option>
                              <option value="Meeting">Visita Agendada</option>
                           </select>
                        </div>
                        <div className="space-y-2">
                           <label className="text-[9px] font-black uppercase text-slate-400 tracking-widest ml-1">Data Agendada</label>
                           <input 
                              type="date" 
                              value={nextStepDate} 
                              onChange={e => setNextStepDate(e.target.value)}
                              className="w-full bg-white border border-slate-200 rounded-xl py-3 px-4 text-xs font-bold outline-none shadow-sm text-slate-900 focus:border-[#d4a853] transition-colors"
                           />
                        </div>
                     </div>

                     <button 
                       onClick={handleAddActivityRecord}
                       className="w-full gold-gradient text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-yellow-900/10 flex items-center justify-center space-x-3 hover:scale-[1.01] active:scale-95 transition-all"
                     >
                        <Save className="w-5 h-5" />
                        <span>Salvar Atendimento Automático</span>
                     </button>
                  </div>
               </div>

               <div className="space-y-6">
                  <h3 className="text-[11px] font-black uppercase tracking-[0.2em] text-slate-400 flex items-center ml-2">
                     <History className="w-4 h-4 mr-2" />
                     Linha do Tempo Integral (Sincronizada)
                  </h3>
                  
                  <div className="relative space-y-6 before:absolute before:inset-0 before:ml-5 before:-translate-x-px before:h-full before:w-0.5 before:bg-slate-100">
                     {activities.filter(a => a.clientName === selectedClient.name).sort((a, b) => new Date(b.updatedAt || b.date).getTime() - new Date(a.updatedAt || a.date).getTime()).map(act => (
                       <div key={act.id} className="relative flex items-center group">
                          <div className="flex items-center justify-center w-10 h-10 rounded-xl border-2 border-white bg-slate-50 text-[#d4a853] shadow-sm z-10 group-hover:bg-[#d4a853] group-hover:text-white transition-all">
                             {getActivityIcon(act.type)}
                          </div>
                          <div className="ml-6 flex-1 p-5 rounded-3xl bg-white border border-slate-100 shadow-sm hover:shadow-md transition-all">
                             <div className="flex items-center justify-between mb-2">
                                <div className="flex items-center space-x-2">
                                   <span className="text-[10px] font-black uppercase tracking-widest text-[#d4a853]">{act.type}</span>
                                   <span className="text-[9px] font-bold text-slate-400 bg-slate-50 px-2 py-0.5 rounded border border-slate-100">Autor: {act.brokerName || 'Corretor'}</span>
                                </div>
                                <div className="flex items-center text-slate-400 space-x-4">
                                   <div className="flex items-center text-[10px] font-bold bg-slate-50 px-2 py-0.5 rounded-lg"><Calendar className="w-3 h-3 mr-1.5 text-slate-400" /> {new Date(act.date).toLocaleDateString('pt-BR')}</div>
                                   <div className="flex items-center text-[10px] font-black text-slate-900 bg-[#d4a853]/10 px-2 py-0.5 rounded-lg border border-[#d4a853]/20"><Clock className="w-3 h-3 mr-1.5 text-[#d4a853]" /> {act.time}</div>
                                </div>
                             </div>
                             <p className="text-sm font-semibold text-slate-700 leading-relaxed">{act.description}</p>
                          </div>
                       </div>
                     ))}
                  </div>
               </div>

            </div>
          </div>
        </div>
      )}
    </div>
  );
};