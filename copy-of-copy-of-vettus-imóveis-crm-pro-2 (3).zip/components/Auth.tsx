
import React, { useState, useRef } from 'react';
import { Mail, Lock, User, ShieldCheck, ArrowRight, Download, Upload, RefreshCw, Key, KeyRound, AlertTriangle } from 'lucide-react';
import { Broker, ALL_PERMISSIONS } from '../types.ts';
import { VettusLogo } from './Layout.tsx';

interface AuthProps {
  onLogin: (user: Broker) => void;
  onRegister: (user: Broker) => void;
  existingBrokers: Broker[];
}

export const Auth: React.FC<AuthProps> = ({ onLogin, onRegister, existingBrokers }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [networkKey, setNetworkKey] = useState('');
  const [error, setError] = useState('');
  const [isImporting, setIsImporting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (isLogin) {
      const user = existingBrokers.find(b => b.email === email.toLowerCase());
      if (user) {
        if (user.blocked) {
          setError('ACESSO SUSPENSO: Este usuário foi bloqueado pelo administrador da rede.');
          return;
        }
        if (user.password && user.password !== password) {
          setError('Sua senha está incorreta. Tente novamente.');
          return;
        }
        onLogin(user);
      } else {
        setError('E-mail não autorizado nesta rede. Peça o convite ao administrador Sergio.');
      }
    } else {
      if (!networkKey) {
        setError('A Chave de Rede é obrigatória para vincular seu notebook à imobiliária.');
        return;
      }

      const exists = existingBrokers.some(b => b.email === email.toLowerCase());
      if (exists) {
        setError('Este e-mail já possui um cadastro ativo neste dispositivo.');
        return;
      }

      const isMaster = email === 'scarrasco462@gmail.com' && (networkKey === 'VETTUS-MASTER-PRO');

      const newUser: Broker = {
        id: Math.random().toString(36).substr(2, 9),
        name: name || (isMaster ? 'Sergio Carrasco Junior' : 'Corretor Vettus'),
        email: email.toLowerCase(),
        password: password,
        role: isMaster ? 'Admin' : 'Broker',
        joinDate: new Date().toISOString().split('T')[0],
        performance: 0,
        networkId: networkKey,
        blocked: false,
        permissions: isMaster ? ALL_PERMISSIONS : ['dashboard', 'tasks', 'properties', 'clients', 'activities', 'reminders']
      };
      
      onRegister(newUser);
      onLogin(newUser);
    }
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsImporting(true);
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = JSON.parse(event.target?.result as string);
        Object.keys(data).forEach(key => localStorage.setItem(key, data[key]));
        alert('Rede Vettus sincronizada com sucesso no notebook!');
        window.location.reload();
      } catch {
        setError('Arquivo de sincronização inválido.');
      } finally {
        setIsImporting(false);
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0a1120] relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full opacity-5 pointer-events-none">
        <div className="absolute top-[-10%] right-[-10%] w-[50%] h-[50%] gold-gradient rounded-full blur-[150px]"></div>
        <div className="absolute bottom-[-10%] left-[-10%] w-[40%] h-[40%] gold-gradient rounded-full blur-[120px]"></div>
      </div>

      <div className="w-full max-w-md p-8 relative z-10 animate-in fade-in zoom-in duration-700">
        <div className="flex flex-col items-center mb-8">
          <VettusLogo className="w-24 h-24 mb-4" />
          <h1 className="text-3xl font-extrabold text-white tracking-[0.1em] uppercase text-center leading-none">VETTUS IMÓVEIS</h1>
          <p className="text-[#d4a853] text-[9px] font-bold tracking-[0.6em] mt-3 text-center uppercase opacity-80">ECOSSISTEMA DE GESTÃO ELITE</p>
        </div>

        <div className="bg-white/5 backdrop-blur-3xl p-8 rounded-[2.5rem] border border-white/10 shadow-2xl">
          <div className="flex mb-8 bg-black/40 p-1.5 rounded-2xl">
            <button 
              onClick={() => { setIsLogin(true); setError(''); }}
              className={`flex-1 py-3 text-xs font-black uppercase tracking-widest rounded-xl transition-all ${isLogin ? 'bg-[#d4a853] text-white shadow-lg' : 'text-slate-500 hover:text-white'}`}
            >
              Entrar
            </button>
            <button 
              onClick={() => { setIsLogin(false); setError(''); }}
              className={`flex-1 py-3 text-xs font-black uppercase tracking-widest rounded-xl transition-all ${!isLogin ? 'bg-[#d4a853] text-white shadow-lg' : 'text-slate-500 hover:text-white'}`}
            >
              Novo Acesso
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Seu Nome</label>
                  <div className="relative">
                    <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#d4a853]" />
                    <input 
                      type="text" required
                      value={name}
                      onChange={e => setName(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-xl py-3.5 pl-12 pr-4 text-white text-sm outline-none focus:ring-2 focus:ring-[#d4a853]/50 transition-all placeholder:text-white/20"
                      placeholder="Nome completo"
                    />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-[#d4a853] uppercase tracking-widest ml-1">Chave de Rede Mestra</label>
                  <div className="relative">
                    <KeyRound className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#d4a853]" />
                    <input 
                      type="text" required
                      value={networkKey}
                      onChange={e => setNetworkKey(e.target.value)}
                      className="w-full bg-white/5 border border-[#d4a853]/30 rounded-xl py-3.5 pl-12 pr-4 text-white text-sm outline-none focus:ring-2 focus:ring-[#d4a853]/50 transition-all placeholder:text-white/20"
                      placeholder="Ex: VETTUS-MASTER-PRO"
                    />
                  </div>
                </div>
              </>
            )}

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">E-mail</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#d4a853]" />
                <input 
                  type="email" required
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-3.5 pl-12 pr-4 text-white text-sm outline-none focus:ring-2 focus:ring-[#d4a853]/50 transition-all placeholder:text-white/20"
                  placeholder="seu@vettus.com"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Senha</label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#d4a853]" />
                <input 
                  type="password" required
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-3.5 pl-12 pr-4 text-white text-sm outline-none focus:ring-2 focus:ring-[#d4a853]/50 transition-all placeholder:text-white/20"
                  placeholder="••••••••"
                />
              </div>
            </div>

            {error && (
              <p className={`text-[10px] text-center font-bold py-2 rounded-lg border flex items-center justify-center space-x-2 ${error.includes('SUSPENSO') ? 'bg-red-500 text-white border-red-600' : 'bg-red-500/10 text-red-400 border-red-500/20'}`}>
                {error.includes('SUSPENSO') && <AlertTriangle className="w-3 h-3" />}
                <span>{error}</span>
              </p>
            )}

            <button 
              type="submit"
              className="w-full gold-gradient text-white py-4 rounded-xl font-bold uppercase tracking-widest text-xs shadow-2xl shadow-yellow-900/40 flex items-center justify-center space-x-3 hover:scale-[1.02] active:scale-95 transition-all mt-6"
            >
              <span>{isLogin ? 'Entrar na Rede Vettus' : 'Vincular Notebook'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          <div className="mt-10 pt-6 border-t border-white/10 flex flex-col items-center">
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="text-[#d4a853] hover:text-white text-[10px] font-black uppercase tracking-widest flex items-center space-x-2 transition-colors border border-[#d4a853]/20 px-4 py-2 rounded-full"
            >
              {isImporting ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
              <span>{isImporting ? 'Sincronizando...' : 'Sincronizar Manualmente (Backup)'}</span>
            </button>
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept=".vettus" 
              onChange={handleImport}
            />
          </div>
        </div>
      </div>
    </div>
  );
};
