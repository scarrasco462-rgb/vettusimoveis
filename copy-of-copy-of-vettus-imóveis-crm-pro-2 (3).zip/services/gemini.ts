
import { GoogleGenAI, Type } from "@google/genai";

/**
 * Funções de serviço para integração com o Google Gemini API.
 * Seguindo as diretrizes oficiais de desenvolvimento do SDK @google/genai.
 */

export const getAISuggestions = async (prompt: string) => {
  try {
    // Instanciação recomendada logo antes da chamada para garantir chaves atualizadas
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [{ parts: [{ text: prompt }] }],
      config: {
        systemInstruction: "Você é um assistente de IA especialista em mercado imobiliário de luxo no Brasil. Ajude corretores a criar descrições persuasivas, analisar leads e sugerir estratégias de fechamento.",
      }
    });
    // Uso da propriedade .text diretamente (não é um método)
    return response.text || "Sem sugestões no momento.";
  } catch (error: any) {
    console.error("AI Error:", error);
    return "O assistente de IA está indisponível no momento.";
  }
};

export const extractPropertyFromUrl = async (url: string) => {
  try {
    // Para tarefas complexas como extração de dados com pesquisa, gemini-3-pro-preview é mais adequado
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: [{ parts: [{ text: `Extraia detalhadamente as informações do imóvel deste link: ${url}.` }] }],
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        // Utilização de responseSchema com propertyOrdering seguindo as diretrizes
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            type: { type: Type.STRING, description: "Apartamento|Casa|Cobertura|Terreno" },
            price: { type: Type.NUMBER },
            address: { type: Type.STRING },
            area: { type: Type.NUMBER },
            bedrooms: { type: Type.NUMBER },
            bathrooms: { type: Type.NUMBER },
            description: { type: Type.STRING },
            status: { type: Type.STRING, description: "Disponível|Lançamento" }
          },
          propertyOrdering: ["title", "type", "price", "address", "area", "bedrooms", "bathrooms", "description", "status"]
        }
      }
    });

    // Extração segura do conteúdo textual
    const text = response.text?.trim() || "{}";
    return JSON.parse(text);
  } catch (error: any) {
    console.error("AI Extraction Error:", error);
    throw error;
  }
};
