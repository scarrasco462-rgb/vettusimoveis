
import React from 'react';
import { ShoppingCart, Download, TrendingUp, User, Building2, Calendar, FileSpreadsheet, BadgeCheck, Clock, ArrowUpRight, Hash, Tag, DollarSign, Award } from 'lucide-react';
import { Commission, Broker } from '../types';

interface SalesViewProps {
  sales: Commission[];
  brokers: Broker[];
}

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 2,
  }).format(value);
};

const getMonthName = (dateString: string) => {
  const date = new Date(dateString);
  return new Intl.DateTimeFormat('pt-BR', { month: 'long', year: 'numeric' }).format(date);
};

export const SalesView: React.FC<SalesViewProps> = ({ sales, brokers }) => {
  const totalVolume = sales.reduce((acc, curr) => acc + (curr.salePrice || 0), 0);
  const totalCommissions = sales.reduce((acc, curr) => acc + curr.amount, 0);
  const totalPaidCommissions = sales.filter(c => c.status === 'Paid').reduce((acc, curr) => acc + curr.amount, 0);

  const getBrokerName = (id: string) => {
    return brokers.find(b => b.id === id)?.name || 'Corretor Externo';
  };

  const groupedSales = sales.reduce((groups, sale) => {
    const month = getMonthName(sale.date);
    if (!groups[month]) {
      groups[month] = [];
    }
    groups[month].push(sale);
    return groups;
  }, {} as Record<string, Commission[]>);

  const sortedMonths = Object.keys(groupedSales).sort((a, b) => {
    return new Date(groupedSales[b][0].date).getTime() - new Date(groupedSales[a][0].date).getTime();
  });

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Relatório Geral de Vendas</h1>
          <p className="text-slate-500">Planilha de fechamento auditada e organizada por período.</p>
        </div>
        <div className="flex items-center space-x-3">
          <button className="flex items-center space-x-2 bg-white border border-slate-200 text-slate-600 px-4 py-2.5 rounded-xl text-xs font-bold hover:bg-slate-50 transition-colors uppercase tracking-widest shadow-sm">
            <FileSpreadsheet className="w-4 h-4 text-green-600" />
            <span>Excel</span>
          </button>
          <button className="flex items-center space-x-2 bg-[#0f172a] text-white px-5 py-2.5 rounded-xl text-xs font-bold hover:bg-slate-800 transition-colors uppercase tracking-widest shadow-lg shadow-slate-200">
            <Download className="w-4 h-4" />
            <span>Relatório PDF</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-[#0f172a] p-6 rounded-[2rem] border border-white/5 shadow-xl relative overflow-hidden group">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-slate-400 text-[10px] font-bold uppercase tracking-[0.2em]">Volume Total Vendido (VGV)</h3>
            <TrendingUp className="w-4 h-4 text-[#d4a853]" />
          </div>
          <p className="text-3xl font-black text-white">{formatCurrency(totalVolume)}</p>
          <div className="mt-3 flex items-center text-[#d4a853] text-[10px] font-bold">
            <ArrowUpRight className="w-3 h-3 mr-1" />
            <span>Transações Consolidadas</span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm relative overflow-hidden group">
           <div className="flex items-center justify-between mb-2">
            <h3 className="text-slate-500 text-[10px] font-bold uppercase tracking-[0.2em]">Total Comissões Vettus</h3>
            <Award className="w-4 h-4 text-[#d4a853]" />
          </div>
          <p className="text-3xl font-black text-slate-900">{formatCurrency(totalCommissions)}</p>
          <p className="mt-3 text-slate-400 text-[10px] font-bold uppercase tracking-widest">Receita bruta gerada</p>
        </div>

        <div className="bg-emerald-50 p-6 rounded-[2rem] border border-emerald-100 shadow-sm relative overflow-hidden group">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-emerald-700 text-[10px] font-bold uppercase tracking-[0.2em]">Pagamentos Liquidados</h3>
            <BadgeCheck className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-3xl font-black text-emerald-900">{formatCurrency(totalPaidCommissions)}</p>
          <p className="mt-3 text-emerald-600/60 text-[10px] font-bold uppercase tracking-widest">Crédito efetivo em conta</p>
        </div>
      </div>

      <div className="space-y-12">
        {sortedMonths.map(month => (
          <div key={month} className="space-y-4">
            <div className="flex items-center space-x-4 ml-2">
              <h2 className="text-sm font-black text-[#d4a853] uppercase tracking-[0.3em]">{month}</h2>
              <div className="h-px flex-1 bg-gradient-to-r from-yellow-200 to-transparent"></div>
            </div>

            <div className="bg-white rounded-[2rem] border border-slate-100 shadow-xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="bg-slate-50 text-slate-400 text-[10px] font-black uppercase tracking-[0.2em]">
                      <th className="px-8 py-5">Data</th>
                      <th className="px-8 py-5">Imóvel e Unidade</th>
                      <th className="px-8 py-5">Time Vettus</th>
                      <th className="px-8 py-5">Venda (VGV)</th>
                      <th className="px-8 py-5">Comissão</th>
                      <th className="px-8 py-5 text-right">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {groupedSales[month].map((sale) => (
                      <tr key={sale.id} className="hover:bg-slate-50/50 transition-colors group">
                        <td className="px-8 py-6">
                          <div className="flex items-center text-slate-500 text-xs font-medium">
                            <Calendar className="w-3.5 h-3.5 mr-2 text-slate-300" />
                            {new Date(sale.date).toLocaleDateString('pt-BR')}
                          </div>
                        </td>
                        <td className="px-8 py-6">
                          <div className="flex flex-col">
                            <div className="flex items-center">
                              <Building2 className="w-4 h-4 mr-3 text-[#d4a853] opacity-60" />
                              <span className="text-sm font-bold text-slate-900 truncate max-w-[200px]">{sale.propertyTitle}</span>
                            </div>
                            <div className="flex items-center mt-1 ml-7 space-x-3">
                               {sale.propertyCode && (
                                 <span className="flex items-center text-[10px] font-black text-slate-400 uppercase">
                                   <Hash className="w-2.5 h-2.5 mr-1" />
                                   {sale.propertyCode}
                                 </span>
                               )}
                               {sale.unitNumber && (
                                 <span className="flex items-center text-[10px] font-black text-[#d4a853] uppercase">
                                   <Tag className="w-2.5 h-2.5 mr-1" />
                                   {sale.unitNumber}
                                 </span>
                               )}
                            </div>
                          </div>
                        </td>
                        <td className="px-8 py-6">
                          <div className="flex flex-col">
                             <div className="flex items-center space-x-2">
                                <div className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center text-[10px] font-bold text-slate-500 border border-slate-200">
                                  {getBrokerName(sale.brokerId)[0]}
                                </div>
                                <span className="text-xs font-semibold text-slate-700">{getBrokerName(sale.brokerId)}</span>
                             </div>
                             <span className="text-[10px] text-slate-400 font-medium ml-8">{sale.clientName}</span>
                          </div>
                        </td>
                        <td className="px-8 py-6">
                           <div className="flex items-center text-xs font-black text-slate-900">
                            <DollarSign className="w-3 h-3 mr-1 text-slate-300" />
                            {formatCurrency(sale.salePrice || 0)}
                          </div>
                        </td>
                        <td className="px-8 py-6">
                          <div className="flex items-center text-sm font-black text-[#d4a853]">
                             <Award className="w-3.5 h-3.5 mr-1.5" />
                             {formatCurrency(sale.amount)}
                          </div>
                        </td>
                        <td className="px-8 py-6 text-right">
                          <span className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border ${
                            sale.status === 'Paid' 
                            ? 'bg-green-50 text-green-600 border-green-100' 
                            : 'bg-yellow-50 text-yellow-600 border-yellow-100'
                          }`}>
                            {sale.status === 'Paid' ? 'Liquidado' : 'Aguardando'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        ))}
        {sales.length === 0 && (
          <div className="bg-white rounded-[2rem] border-2 border-dashed border-slate-100 py-32 text-center">
            <ShoppingCart className="w-12 h-12 text-slate-200 mx-auto mb-4" />
            <p className="text-slate-400 font-bold italic">Nenhum fechamento registrado para este período.</p>
          </div>
        )}
      </div>
    </div>
  );
};
