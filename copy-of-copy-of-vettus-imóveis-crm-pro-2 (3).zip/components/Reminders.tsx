
import React from 'react';
import { CheckCircle2, Circle, AlertCircle, Plus } from 'lucide-react';
import { Reminder } from '../types';

interface ReminderViewProps {
  reminders: Reminder[];
  onToggleReminder: (id: string) => void;
}

export const ReminderView: React.FC<ReminderViewProps> = ({ reminders, onToggleReminder }) => {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Seus Lembretes</h1>
          <p className="text-slate-500">Mantenha sua produtividade focada em seus próprios compromissos.</p>
        </div>
        <button className="gold-gradient text-white p-3 rounded-full shadow-lg hover:scale-105 transition-transform">
          <Plus className="w-6 h-6" />
        </button>
      </div>

      <div className="space-y-4">
        {reminders.map((reminder) => (
          <div 
            key={reminder.id} 
            className={`bg-white p-6 rounded-2xl border border-slate-100 shadow-sm flex items-center space-x-4 hover:shadow-md transition-all group ${reminder.completed ? 'opacity-60 bg-slate-50/50' : ''}`}
          >
            <button 
              onClick={() => onToggleReminder(reminder.id)}
              className={`transition-all hover:scale-110 active:scale-90 ${reminder.completed ? 'text-green-500' : 'text-slate-300 group-hover:text-[#d4a853]'}`}
              title={reminder.completed ? "Marcar como pendente" : "Marcar como concluído"}
            >
              {reminder.completed ? <CheckCircle2 className="w-6 h-6" /> : <Circle className="w-6 h-6" />}
            </button>
            <div className="flex-1">
              <div className="flex items-center space-x-2">
                <h3 className={`font-bold transition-all ${reminder.completed ? 'text-slate-400 line-through' : 'text-slate-900'}`}>
                  {reminder.title}
                </h3>
                {reminder.priority === 'High' && !reminder.completed && (
                  <AlertCircle className="w-4 h-4 text-red-500 animate-pulse" />
                )}
              </div>
              <p className="text-sm text-slate-400 mt-1">Vence em: {new Date(reminder.dueDate).toLocaleDateString('pt-BR')}</p>
            </div>
            {!reminder.completed && (
              <div className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest ${
                reminder.priority === 'High' ? 'bg-red-50 text-red-600' : 
                reminder.priority === 'Medium' ? 'bg-orange-50 text-orange-600' : 'bg-blue-50 text-blue-600'
              }`}>
                Prioridade {reminder.priority === 'High' ? 'Alta' : reminder.priority === 'Medium' ? 'Média' : 'Baixa'}
              </div>
            )}
            {reminder.completed && (
              <span className="text-[10px] font-bold text-green-600 uppercase tracking-widest bg-green-50 px-3 py-1 rounded-full">
                Concluído
              </span>
            )}
          </div>
        ))}
        {reminders.length === 0 && (
          <div className="py-20 text-center text-slate-400 italic">Você não possui lembretes ativos.</div>
        )}
      </div>
    </div>
  );
};
