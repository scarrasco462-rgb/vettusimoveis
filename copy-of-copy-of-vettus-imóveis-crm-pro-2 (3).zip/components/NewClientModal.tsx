
import React, { useState, useEffect } from 'react';
import { Mail, Phone, UserPlus, X, User, DollarSign, Briefcase, Tag, Target, ShieldCheck, Heart, Save, CheckCircle2, RefreshCw, Zap, Pencil } from 'lucide-react';
import { Client, ClientStatus, Broker } from '../types';

interface NewClientModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddClient: (client: Client) => void;
  onUpdateClient?: (client: Client) => void;
  clientToEdit?: Client | null;
  currentUser: Broker;
  brokers: Broker[];
}

const formatDisplayNumber = (value: number) => {
  return value.toLocaleString('pt-BR', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
};

const parseCurrencyToNumber = (value: string): number => {
  const cleanValue = value.replace(/[^\d]/g, '');
  return cleanValue ? parseFloat(cleanValue) / 100 : 0;
};

export const NewClientModal: React.FC<NewClientModalProps> = ({ 
  isOpen, 
  onClose, 
  onAddClient, 
  onUpdateClient, 
  clientToEdit, 
  currentUser, 
  brokers 
}) => {
  const [formData, setFormData] = useState<Partial<Client>>({
    name: '',
    email: '',
    phone: '',
    status: ClientStatus.FIRST_CONTACT,
    budget: 0,
    preference: '',
    brokerId: currentUser.id
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen) {
      if (clientToEdit) {
        setFormData(clientToEdit);
      } else {
        setFormData({
          name: '',
          email: '',
          phone: '',
          status: ClientStatus.FIRST_CONTACT,
          budget: 0,
          preference: '',
          brokerId: currentUser.id
        });
      }
    }
  }, [isOpen, clientToEdit, currentUser]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;

    if (!formData.name || !formData.phone) {
      alert("Para o cadastro, Nome e WhatsApp são obrigatórios.");
      return;
    }

    setIsSubmitting(true);

    try {
      const selectedBroker = brokers.find(b => b.id === formData.brokerId) || currentUser;
      
      const clientData: Client = {
        id: clientToEdit?.id || Math.random().toString(36).substr(2, 9),
        brokerId: selectedBroker.id,
        name: formData.name || '',
        email: formData.email || '',
        phone: formData.phone || '',
        status: formData.status as ClientStatus,
        lastContact: clientToEdit?.lastContact || new Date().toISOString().split('T')[0],
        budget: formData.budget || 0,
        assignedAgent: selectedBroker.name,
        preference: formData.preference || '',
        updatedAt: new Date().toISOString()
      };

      if (clientToEdit && onUpdateClient) {
        onUpdateClient(clientData);
      } else {
        onAddClient(clientData);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[150] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-[#0a1120]/95 backdrop-blur-md" onClick={onClose}></div>
      <div className="bg-white w-full max-w-2xl rounded-[2.5rem] p-0 relative z-10 shadow-2xl animate-in zoom-in duration-300 overflow-hidden max-h-[90vh] flex flex-col border border-white/20">
        
        <div className="navy-gradient p-8 text-white shrink-0 border-b border-white/10">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-14 h-14 gold-gradient rounded-2xl flex items-center justify-center shadow-2xl">
                {clientToEdit ? <Pencil className="w-7 h-7 text-white" /> : <UserPlus className="w-7 h-7 text-white" />}
              </div>
              <div>
                <h2 className="text-2xl font-bold uppercase tracking-tight">{clientToEdit ? 'Atualizar Lead' : 'Cadastro de Lead'}</h2>
                <p className="text-slate-400 text-sm">{clientToEdit ? 'Modificando dados na rede.' : 'Sincronização P2P Ativada.'} <Zap className="inline w-3 h-3 text-yellow-400" /></p>
              </div>
            </div>
            <button onClick={onClose} className="p-3 hover:bg-white/10 rounded-full transition-colors">
              <X className="w-7 h-7 text-white" />
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="overflow-y-auto p-8 bg-slate-50 space-y-8 no-scrollbar flex-1">
          
          <section className="space-y-4">
            <div className="flex items-center space-x-2 border-b border-slate-200 pb-2">
              <User className="w-4 h-4 text-[#d4a853]" />
              <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Dados do Cliente</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1 md:col-span-2">
                <label className="text-[10px] font-bold text-slate-500 uppercase ml-1">Nome Completo *</label>
                <input 
                  type="text" required 
                  value={formData.name} 
                  onChange={e => setFormData({...formData, name: e.target.value})} 
                  placeholder="Ex: João da Silva"
                  className="w-full bg-white border border-slate-200 rounded-xl py-4 px-4 text-sm font-bold text-slate-900 outline-none focus:ring-2 focus:ring-[#d4a853]/50 transition-all shadow-sm" 
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-[#d4a853] uppercase ml-1">WhatsApp (Obrigatório) *</label>
                <div className="relative">
                  <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#d4a853]" />
                  <input 
                    type="tel" required 
                    value={formData.phone} 
                    onChange={e => setFormData({...formData, phone: e.target.value})} 
                    placeholder="(00) 00000-0000"
                    className="w-full bg-white border border-[#d4a853]/20 rounded-xl py-4 pl-12 pr-4 text-sm font-black text-slate-900 outline-none focus:ring-2 focus:ring-[#d4a853]/50 transition-all shadow-sm" 
                  />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase ml-1">E-mail</label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                  <input 
                    type="email"
                    value={formData.email} 
                    onChange={e => setFormData({...formData, email: e.target.value})} 
                    placeholder="email@cliente.com"
                    className="w-full bg-white border border-slate-200 rounded-xl py-4 pl-12 pr-4 text-sm font-bold text-slate-900 outline-none focus:ring-2 focus:ring-[#d4a853]/50 transition-all shadow-sm" 
                  />
                </div>
              </div>
            </div>
          </section>

          <section className="space-y-4">
            <div className="flex items-center space-x-2 border-b border-slate-200 pb-2">
              <Target className="w-4 h-4 text-[#d4a853]" />
              <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Qualificação</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-[#d4a853] uppercase ml-1">Orçamento (R$)</label>
                <div className="relative">
                  <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#d4a853]" />
                  <input 
                    type="text"
                    value={formatDisplayNumber(formData.budget || 0)}
                    onChange={e => setFormData({...formData, budget: parseCurrencyToNumber(e.target.value)})}
                    className="w-full bg-white border border-[#d4a853]/30 rounded-xl py-4 pl-12 pr-4 text-slate-900 font-black text-sm outline-none focus:ring-2 focus:ring-[#d4a853]/50 shadow-sm"
                  />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase ml-1">Temperatura</label>
                <select 
                  value={formData.status}
                  onChange={e => setFormData({...formData, status: e.target.value as ClientStatus})}
                  className="w-full bg-white border border-slate-200 rounded-xl py-4 px-4 text-sm font-bold text-slate-900 outline-none cursor-pointer shadow-sm"
                >
                  <option value={ClientStatus.FIRST_CONTACT}>Primeiro Contato</option>
                  <option value={ClientStatus.HOT}>🔥 Quente (Pronto)</option>
                  <option value={ClientStatus.WARM}>⚡ Morno (Pesquisa)</option>
                  <option value={ClientStatus.COLD}>❄️ Frio (Futuro)</option>
                </select>
              </div>
            </div>
          </section>

          <div className="pt-4">
            <button 
              type="submit" 
              disabled={isSubmitting}
              className={`w-full gold-gradient text-white py-5 rounded-2xl font-black text-sm uppercase tracking-widest shadow-2xl shadow-yellow-900/30 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center space-x-3 ${isSubmitting ? 'opacity-70 cursor-wait' : ''}`}
            >
              {isSubmitting ? (
                <RefreshCw className="w-6 h-6 animate-spin" />
              ) : (
                <CheckCircle2 className="w-6 h-6" />
              )}
              <span>{isSubmitting ? 'Distribuindo na Rede...' : (clientToEdit ? 'Confirmar Atualização' : 'Finalizar e Sincronizar')}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
