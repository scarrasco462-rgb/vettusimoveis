
import React, { useState, useEffect } from 'react';
import { 
  Database, 
  Download, 
  ShieldCheck, 
  History, 
  Clock, 
  FileCheck, 
  AlertCircle, 
  HardDrive,
  FolderOpen,
  ArrowRight,
  Info,
  RefreshCw,
  Server,
  Copy,
  CheckCircle2
} from 'lucide-react';
import { Broker } from '../types';

interface BackupProps {
  currentUser: Broker;
  onManualBackup: () => void;
}

export const Backup: React.FC<BackupProps> = ({ currentUser, onManualBackup }) => {
  const [lastBackup, setLastBackup] = useState<string>('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('vettus_v3_core_last_backup_date');
    if (saved) setLastBackup(new Date(saved).toLocaleString('pt-BR'));
  }, []);

  const adminPath = "C:\\Users\\scarr\\OneDrive\\Desktop\\BACKUP SISTEMA VETTUS";

  const handleCopyPath = () => {
    navigator.clipboard.writeText(adminPath);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 flex items-center">
            <Database className="w-6 h-6 mr-3 text-[#d4a853]" />
            Central de Backup & Segurança
          </h1>
          <p className="text-slate-500 text-sm mt-1">Sincronização redundante para o servidor do Administrador.</p>
        </div>
        <div className="bg-emerald-50 text-emerald-600 px-4 py-2 rounded-xl border border-emerald-100 flex items-center space-x-2">
           <ShieldCheck className="w-4 h-4" />
           <span className="text-[10px] font-black uppercase tracking-widest">Vault Vettus Ativo</span>
        </div>
      </div>

      <div className="bg-[#0a1120] p-10 rounded-[3rem] text-white border border-white/5 relative overflow-hidden group shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#d4a853]/10 rounded-full blur-[100px] -mr-48 -mt-48 transition-all group-hover:bg-[#d4a853]/20"></div>
        <div className="relative z-10">
          <div className="flex items-center space-x-4 mb-8">
            <div className="w-16 h-16 gold-gradient rounded-3xl flex items-center justify-center shadow-2xl animate-pulse">
              <Server className="w-8 h-8 text-white" />
            </div>
            <div>
              <h3 className="text-xl font-bold tracking-tight">Endereço de Salvamento Local</h3>
              <p className="text-slate-400 text-xs font-medium uppercase tracking-widest">Diretório Root do Administrador</p>
            </div>
          </div>
          
          <div className="flex flex-col md:flex-row md:items-center gap-4">
            <div className="flex-1 bg-white/5 p-5 rounded-2xl border border-white/10 font-mono text-xs text-[#d4a853] break-all flex items-center justify-between group/path">
              <span>{adminPath}</span>
              <button 
                onClick={handleCopyPath}
                className="p-2 hover:bg-white/10 rounded-lg transition-all text-white/40 hover:text-[#d4a853]"
                title="Copiar Caminho"
              >
                {copied ? <CheckCircle2 className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
            <button 
              onClick={onManualBackup}
              className="gold-gradient text-white px-8 py-5 rounded-2xl font-black uppercase tracking-[0.1em] text-xs shadow-xl shadow-yellow-900/20 flex items-center justify-center space-x-3 hover:scale-[1.02] active:scale-95 transition-all shrink-0"
            >
              <Download className="w-5 h-5" />
              <span>Sincronizar Agora</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-10 border-t border-white/10 pt-10">
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 rounded-full bg-emerald-500/10 flex items-center justify-center shrink-0 border border-emerald-500/20">
                <FileCheck className="w-4 h-4 text-emerald-500" />
              </div>
              <div>
                <p className="text-[11px] font-bold text-white uppercase tracking-tighter">Auto-Save Ativado</p>
                <p className="text-[10px] text-slate-500">Backup automático ao fechar.</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 rounded-full bg-blue-500/10 flex items-center justify-center shrink-0 border border-blue-500/20">
                <RefreshCw className="w-4 h-4 text-blue-500" />
              </div>
              <div>
                <p className="text-[11px] font-bold text-white uppercase tracking-tighter">Último Ciclo</p>
                <p className="text-[10px] text-slate-500">{lastBackup || 'Pendente'}</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 rounded-full bg-purple-500/10 flex items-center justify-center shrink-0 border border-purple-500/20">
                <HardDrive className="w-4 h-4 text-purple-500" />
              </div>
              <div>
                <p className="text-[11px] font-bold text-white uppercase tracking-tighter">Espelhamento Cloud</p>
                <p className="text-[10px] text-slate-500">OneDrive Desktop Sync.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm">
        <div className="flex items-center space-x-3 mb-8">
           <div className="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center text-[#d4a853]">
              <Info className="w-5 h-5" />
           </div>
           <h3 className="text-lg font-bold text-slate-900">Como configurar o salvamento direto</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          <div className="space-y-6">
            <div className="flex items-start space-x-4">
              <div className="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs font-bold shrink-0">1</div>
              <p className="text-sm text-slate-600 leading-relaxed font-medium">
                Abra as configurações do seu navegador (Chrome/Edge) e vá em <strong className="text-slate-900">Downloads</strong>.
              </p>
            </div>
            <div className="flex items-start space-x-4">
              <div className="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs font-bold shrink-0">2</div>
              <p className="text-sm text-slate-600 leading-relaxed font-medium">
                Altere o local padrão para: <br/>
                <code className="bg-slate-50 text-[10px] px-2 py-1 rounded border border-slate-200 mt-2 block font-mono text-[#d4a853]">
                  {adminPath}
                </code>
              </p>
            </div>
          </div>
          <div className="bg-slate-50 p-6 rounded-3xl border border-slate-200 flex flex-col justify-center">
             <div className="flex items-center space-x-3 text-red-500 mb-2">
                <AlertCircle className="w-5 h-5" />
                <p className="text-xs font-bold uppercase tracking-widest">Aviso de Segurança</p>
             </div>
             <p className="text-[11px] text-slate-500 leading-relaxed">
               Este procedimento garante que o Vettus CRM exporte os dados diretamente para sua pasta do OneDrive sem que o navegador pergunte "Onde salvar" a cada fechamento. 
               <br/><br/>
               Isso cria um <strong>espelhamento em tempo real</strong> entre o sistema e sua pasta de segurança no Desktop.
             </p>
          </div>
        </div>
      </div>
    </div>
  );
};
