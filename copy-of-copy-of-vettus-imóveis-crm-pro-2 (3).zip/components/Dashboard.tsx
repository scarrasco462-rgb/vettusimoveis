
import React, { useState, useEffect } from 'react';
import { TrendingUp, Users, Home, Wallet, ChevronRight, Sparkles, ShieldCheck, Activity as ActivityIcon, Monitor, Clock, UserCheck } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { getAISuggestions } from '../services/gemini.ts';
import { Property, Client, Task, Activity, Reminder, Commission, Campaign, Broker, SystemActivity } from '../types.ts';
// Fix: Added missing import for MOCK_BROKERS
import { MOCK_BROKERS } from '../constants.tsx';

const chartData = [
  { name: 'Jan', value: 4000 },
  { name: 'Fev', value: 3000 },
  { name: 'Mar', value: 2000 },
  { name: 'Abr', value: 2780 },
  { name: 'Mai', value: 1890 },
  { name: 'Jun', value: 2390 },
  { name: 'Jul', value: 3490 },
];

interface DashboardProps {
  onNavigate: (view: any) => void;
  currentUser: Broker;
  statsData: {
    properties: Property[];
    clients: Client[];
    tasks: Task[];
    activities: Activity[];
    reminders: Reminder[];
    commissions: Commission[];
    campaigns: Campaign[];
    systemLogs: SystemActivity[];
    onlineBrokers: string[];
  };
}

export const Dashboard: React.FC<DashboardProps> = ({ onNavigate, statsData, currentUser }) => {
  const [aiInsight, setAiInsight] = useState<string>("Analisando dados estratégicos da rede Vettus...");

  useEffect(() => {
    const fetchInsight = async () => {
      const insight = await getAISuggestions("Como corretor de elite, dê uma dica curta sobre fechamento de vendas de luxo.");
      setAiInsight(insight);
    };
    fetchInsight();
  }, []);

  const totalSalesValue = statsData.tasks.filter(t => t.stage === 'Fechamento').reduce((acc, t) => acc + t.value, 0);
  const totalCommission = statsData.commissions.reduce((acc, c) => acc + c.amount, 0);

  const stats = [
    { label: 'Volume Negociado', value: `R$ ${(totalSalesValue / 1000000).toFixed(1)}M`, icon: Wallet, color: 'text-green-600', bg: 'bg-green-100' },
    { label: 'Leads Ativos', value: statsData.clients.length.toString(), icon: Users, color: 'text-blue-600', bg: 'bg-blue-100' },
    { label: 'Portfólio de Imóveis', value: statsData.properties.length.toString(), icon: Home, color: 'text-purple-600', bg: 'bg-purple-100' },
    { label: 'Expectativa Comissões', value: `R$ ${(totalCommission / 1000).toFixed(0)}K`, icon: TrendingUp, color: 'text-[#d4a853]', bg: 'bg-yellow-100' },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight uppercase">Vettus Analytics</h1>
          <p className="text-slate-500 mt-1 font-medium">Ecossistema de Inteligência Imobiliária.</p>
        </div>
        <div className="flex items-center space-x-2 bg-slate-100 px-4 py-2 rounded-xl border border-slate-200">
           <ShieldCheck className="w-4 h-4 text-[#d4a853]" />
           <span className="text-[10px] font-black uppercase tracking-widest text-slate-600">Ambiente Criptografado</span>
        </div>
      </div>

      <div className="bg-[#0f172a] rounded-3xl p-8 relative overflow-hidden group shadow-2xl">
        <div className="absolute top-0 right-0 w-64 h-64 bg-[#d4a853]/10 rounded-full blur-[80px] -mr-32 -mt-32"></div>
        <div className="relative z-10">
          <div className="flex items-center space-x-2 text-[#d4a853] mb-4 font-black text-xs uppercase tracking-[0.2em]">
            <Sparkles className="w-4 h-4 animate-pulse" />
            <span>Vettus AI Assistant</span>
          </div>
          <p className="text-white text-xl md:text-2xl font-medium leading-relaxed italic opacity-90">"{aiInsight}"</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, idx) => (
          <div key={idx} className="bg-white p-7 rounded-[2rem] shadow-sm border border-slate-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
            <div className={`w-14 h-14 rounded-2xl ${stat.bg} ${stat.color} flex items-center justify-center mb-5 shadow-sm`}>
              <stat.icon className="w-7 h-7" />
            </div>
            <h3 className="text-slate-400 text-[10px] font-black uppercase tracking-widest">{stat.label}</h3>
            <p className="text-3xl font-black text-slate-900 mt-1 tracking-tighter">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 pb-10">
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm">
            <div className="flex items-center justify-between mb-10">
              <h2 className="text-lg font-black text-slate-900 uppercase tracking-widest">Performance de Rede</h2>
              <div className="flex space-x-2">
                 <div className="flex items-center space-x-1">
                    <div className="w-3 h-3 rounded-full bg-[#d4a853]"></div>
                    <span className="text-[9px] font-bold text-slate-400 uppercase">Projeção</span>
                 </div>
              </div>
            </div>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10, fontWeight: 700}} />
                  <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10, fontWeight: 700}} />
                  <Tooltip 
                    cursor={{fill: '#f8fafc'}} 
                    contentStyle={{borderRadius: '20px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', padding: '15px'}} 
                  />
                  <Bar dataKey="value" fill="#d4a853" radius={[8, 8, 0, 0]} barSize={35} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Monitor de Rede para o Administrador */}
          {currentUser.role === 'Admin' && (
            <div className="bg-[#0f172a] p-8 rounded-[2.5rem] text-white border border-white/5 relative overflow-hidden shadow-2xl">
              <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full blur-[60px] -mr-16 -mt-16"></div>
              <div className="flex items-center justify-between mb-8">
                 <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-blue-500/20 rounded-xl flex items-center justify-center">
                       <Monitor className="w-6 h-6 text-blue-400" />
                    </div>
                    <h2 className="text-lg font-black uppercase tracking-widest">Monitoramento em Tempo Real</h2>
                 </div>
                 <div className="flex items-center space-x-2 bg-blue-500/10 px-3 py-1 rounded-full border border-blue-500/20">
                    <div className="w-2 h-2 rounded-full bg-blue-400 animate-pulse"></div>
                    <span className="text-[9px] font-black uppercase tracking-widest text-blue-400">Ao Vivo</span>
                 </div>
              </div>

              <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2 no-scrollbar">
                {statsData.systemLogs.map((log) => (
                  <div key={log.id} className="bg-white/5 p-4 rounded-2xl border border-white/5 flex items-center justify-between hover:bg-white/10 transition-all group">
                    <div className="flex items-center space-x-4">
                       <div className="w-10 h-10 rounded-xl gold-gradient flex items-center justify-center font-black text-xs text-white">
                          {log.brokerName[0]}
                       </div>
                       <div>
                          <p className="text-xs font-bold text-white group-hover:text-[#d4a853] transition-colors">
                            <span className="text-blue-400">{log.brokerName}</span> {log.action}
                          </p>
                          <p className="text-[10px] text-slate-500 font-medium">Alvo: {log.target}</p>
                       </div>
                    </div>
                    <div className="text-right">
                       <div className="flex items-center text-[9px] font-black text-slate-400 uppercase tracking-widest">
                          <Clock className="w-3 h-3 mr-1 text-[#d4a853]" />
                          {new Date(log.timestamp).toLocaleTimeString('pt-BR')}
                       </div>
                    </div>
                  </div>
                ))}
                {statsData.systemLogs.length === 0 && (
                  <div className="py-20 text-center text-slate-500 italic text-sm">Aguardando movimentação dos corretores na rede...</div>
                )}
              </div>
            </div>
          )}
        </div>

        <div className="space-y-8">
           <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-lg font-black text-slate-900 uppercase tracking-widest">Atividades Recentes</h2>
              <button onClick={() => onNavigate('activities')} className="text-[#d4a853] text-[10px] font-black uppercase tracking-widest hover:underline">Ver Tudo</button>
            </div>
            <div className="space-y-6">
              {statsData.activities.slice(0, 6).map((activity) => (
                <div key={activity.id} className="flex items-start space-x-4 group cursor-pointer">
                  <div className="w-12 h-12 rounded-2xl bg-slate-50 flex items-center justify-center flex-shrink-0 group-hover:bg-[#d4a853] group-hover:text-white transition-all border border-slate-100">
                    <ActivityIcon className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold text-slate-900 truncate group-hover:text-[#d4a853] transition-colors">{activity.description}</p>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">{activity.time} • {activity.clientName}</p>
                  </div>
                </div>
              ))}
              {statsData.activities.length === 0 && (
                <div className="py-20 text-center text-slate-300 italic font-medium">Nenhuma atividade recente detectada na rede.</div>
              )}
            </div>
          </div>

          {currentUser.role === 'Admin' && (
            <div className="bg-emerald-900 p-8 rounded-[2.5rem] text-white shadow-xl relative overflow-hidden group">
               <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-400/10 rounded-full blur-[50px] -mr-16 -mt-16 group-hover:bg-emerald-400/20 transition-all"></div>
               <div className="flex items-center space-x-3 mb-6">
                  <UserCheck className="w-6 h-6 text-emerald-400" />
                  <h3 className="text-lg font-black uppercase tracking-widest">Corretores Online</h3>
               </div>
               <div className="space-y-3">
                  {statsData.onlineBrokers.map(id => {
                    const b = MOCK_BROKERS.find(br => br.id === id);
                    return (
                      <div key={id} className="flex items-center justify-between bg-white/5 p-3 rounded-xl border border-white/5">
                        <span className="text-xs font-bold">{b?.name || `Corretor ${id}`}</span>
                        <span className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.6)]"></span>
                      </div>
                    );
                  })}
                  {statsData.onlineBrokers.length === 0 && (
                    <p className="text-[10px] text-emerald-400/60 font-medium italic">Nenhum corretor ativo no momento.</p>
                  )}
               </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
