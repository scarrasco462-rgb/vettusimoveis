
import React, { useState, useRef } from 'react';
import { 
  FileUp, 
  UploadCloud, 
  CheckCircle, 
  AlertCircle, 
  X, 
  Loader2, 
  UserPlus, 
  Mail, 
  Phone, 
  Zap,
  Info,
  FileSpreadsheet
} from 'lucide-react';
import { Client, ClientStatus, Broker } from '../types';
import * as XLSX from 'https://esm.sh/xlsx@0.18.5';

interface LeadImportProps {
  onImportLeads: (leads: Client[]) => void;
  currentUser: Broker;
}

export const LeadImport: React.FC<LeadImportProps> = ({ onImportLeads, currentUser }) => {
  const [dragActive, setDragActive] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [parsing, setParsing] = useState(false);
  const [previewLeads, setPreviewLeads] = useState<Partial<Client>[]>([]);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleFile = (selectedFile: File) => {
    const ext = selectedFile.name.split('.').pop()?.toLowerCase();
    if (!['csv', 'xlsx', 'xls'].includes(ext || '')) {
      setError("Por favor, selecione uma planilha válida (.xlsx, .xls ou .csv).");
      return;
    }
    setFile(selectedFile);
    setError(null);
    parseSpreadsheet(selectedFile);
  };

  const parseSpreadsheet = (file: File) => {
    setParsing(true);
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const json: any[] = XLSX.utils.sheet_to_json(worksheet);

        const extracted: Partial<Client>[] = json.map(row => {
          // Normalização de chaves para aceitar variações comuns
          const findVal = (terms: string[]) => {
            const key = Object.keys(row).find(k => terms.some(t => k.toLowerCase().includes(t.toLowerCase())));
            return key ? row[key] : null;
          };

          const name = findVal(['nome', 'name', 'cliente', 'lead']) || "Desconhecido";
          const email = findVal(['email', 'e-mail', 'mail']) || "";
          const phone = String(findVal(['phone', 'telefone', 'whatsapp', 'celular', 'contato']) || "");
          const budgetRaw = findVal(['budget', 'orcamento', 'orçamento', 'preco', 'preço', 'valor']);
          const preference = findVal(['preference', 'preferencia', 'preferência', 'interesse', 'imovel', 'imóvel']) || "";

          return {
            name: String(name),
            email: String(email),
            phone: phone.replace(/[^\d+]/g, ''),
            budget: Number(String(budgetRaw).replace(/[^\d,]/g, '').replace(',', '.')) || 0,
            status: ClientStatus.FIRST_CONTACT,
            preference: String(preference)
          };
        });

        if (extracted.length === 0) {
          setError("Não encontramos dados válidos nesta planilha.");
        } else {
          setPreviewLeads(extracted);
        }
      } catch (err) {
        console.error(err);
        setError("Erro ao ler o arquivo. Verifique se a planilha não está corrompida.");
      } finally {
        setParsing(false);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const confirmImport = () => {
    const finalLeads: Client[] = previewLeads.map(lead => ({
      id: Math.random().toString(36).substr(2, 9),
      brokerId: currentUser.id,
      name: lead.name || 'Sem Nome',
      email: lead.email || '',
      phone: lead.phone || '',
      status: ClientStatus.FIRST_CONTACT,
      lastContact: new Date().toISOString().split('T')[0],
      budget: lead.budget || 0,
      assignedAgent: currentUser.name,
      preference: lead.preference || '',
      updatedAt: new Date().toISOString()
    }));

    onImportLeads(finalLeads);
    setFile(null);
    setPreviewLeads([]);
    alert(`${finalLeads.length} leads importados com sucesso para o Vettus!`);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Importação de Lista de Leads</h1>
          <p className="text-slate-500 text-sm mt-1">Transforme planilhas Excel ou CSV em oportunidades reais de venda.</p>
        </div>
        <div className="bg-white px-4 py-2 rounded-xl border border-slate-200 flex items-center space-x-2">
           <Zap className="w-4 h-4 text-[#d4a853]" />
           <span className="text-[10px] font-black uppercase tracking-widest text-slate-500">Data Sync Vettus</span>
        </div>
      </div>

      {!file ? (
        <div 
          onDragEnter={handleDrag} 
          onDragLeave={handleDrag} 
          onDragOver={handleDrag} 
          onDrop={handleDrop}
          onClick={() => inputRef.current?.click()}
          className={`relative h-96 rounded-[3rem] border-4 border-dashed transition-all flex flex-col items-center justify-center cursor-pointer group ${
            dragActive ? 'bg-[#d4a853]/10 border-[#d4a853] scale-[0.99]' : 'bg-white border-slate-100 hover:border-[#d4a853]/30 hover:bg-slate-50'
          }`}
        >
          <input ref={inputRef} type="file" className="hidden" accept=".xlsx,.xls,.csv" onChange={(e) => e.target.files && handleFile(e.target.files[0])} />
          
          <div className="w-24 h-24 rounded-3xl gold-gradient flex items-center justify-center shadow-2xl mb-6 group-hover:scale-110 transition-transform">
             <UploadCloud className="w-12 h-12 text-white" />
          </div>
          
          <h2 className="text-xl font-bold text-slate-900 mb-2">Arraste sua Planilha (Excel/CSV)</h2>
          <p className="text-slate-400 text-sm font-medium">Clique aqui para selecionar do seu computador</p>
          
          <div className="mt-8 flex items-center space-x-6">
             <div className="flex items-center space-x-2 text-[10px] font-black uppercase tracking-widest text-slate-400">
                <FileSpreadsheet className="w-4 h-4" />
                <span>Formatos Suportados: .XLSX, .XLS, .CSV</span>
             </div>
          </div>

          {error && (
            <div className="absolute bottom-10 bg-red-500 text-white px-6 py-2 rounded-full text-xs font-bold flex items-center space-x-2 shadow-xl animate-in slide-in-from-bottom-2">
               <AlertCircle className="w-4 h-4" />
               <span>{error}</span>
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-6">
           <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-xl space-y-6">
              <div className="flex items-center justify-between border-b border-slate-100 pb-6">
                 <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-slate-100 rounded-2xl flex items-center justify-center text-[#d4a853]">
                       <FileSpreadsheet className="w-6 h-6" />
                    </div>
                    <div>
                       <h3 className="text-lg font-bold text-slate-900">{file.name}</h3>
                       <p className="text-xs text-slate-400">Análise estrutural: {previewLeads.length} leads prontos para entrada</p>
                    </div>
                 </div>
                 <button onClick={() => { setFile(null); setPreviewLeads([]); }} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                    <X className="w-6 h-6 text-slate-400" />
                 </button>
              </div>

              {parsing ? (
                <div className="py-20 flex flex-col items-center justify-center space-y-4">
                   <Loader2 className="w-10 h-10 text-[#d4a853] animate-spin" />
                   <p className="text-sm font-bold text-slate-500 uppercase tracking-widest">Processando Planilha...</p>
                </div>
              ) : (
                <div className="space-y-4 max-h-96 overflow-y-auto pr-2 no-scrollbar">
                   {previewLeads.map((lead, i) => (
                     <div key={i} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100 hover:border-[#d4a853]/30 transition-all">
                        <div className="flex items-center space-x-4">
                           <div className="w-10 h-10 rounded-xl gold-gradient flex items-center justify-center text-white text-xs font-black">
                              {lead.name?.[0]}
                           </div>
                           <div>
                              <p className="text-sm font-bold text-slate-900">{lead.name}</p>
                              <div className="flex items-center space-x-3 mt-0.5">
                                 <span className="text-[10px] text-slate-400 flex items-center font-medium"><Mail className="w-2.5 h-2.5 mr-1" /> {lead.email || 'N/A'}</span>
                                 <span className="text-[10px] text-slate-400 flex items-center font-medium"><Phone className="w-2.5 h-2.5 mr-1" /> {lead.phone || 'N/A'}</span>
                              </div>
                           </div>
                        </div>
                        <div className="text-right">
                           <p className="text-[9px] font-black uppercase text-[#d4a853] tracking-widest">Previsão</p>
                           <p className="text-sm font-black text-slate-900">R$ {lead.budget?.toLocaleString('pt-BR')}</p>
                        </div>
                     </div>
                   ))}
                </div>
              )}

              <div className="pt-6 border-t border-slate-100 flex items-center justify-between">
                 <div className="flex items-center text-xs text-slate-400 bg-slate-50 px-4 py-2 rounded-xl">
                    <Info className="w-4 h-4 mr-2" />
                    <span>Importação direta para a carteira de: <strong>{currentUser.name}</strong></span>
                 </div>
                 <button 
                  onClick={confirmImport}
                  className="gold-gradient text-white px-10 py-4 rounded-2xl font-black uppercase tracking-widest text-xs shadow-xl shadow-yellow-900/20 hover:scale-[1.02] active:scale-95 transition-all flex items-center space-x-3"
                 >
                    <UserPlus className="w-5 h-5" />
                    <span>Confirmar e Importar Lista</span>
                 </button>
              </div>
           </div>
        </div>
      )}

      <div className="bg-[#0a1120] p-8 rounded-[2.5rem] text-white border border-white/5 relative overflow-hidden">
         <div className="absolute top-0 right-0 w-64 h-64 bg-[#d4a853]/5 rounded-full blur-[80px]"></div>
         <h3 className="text-sm font-black uppercase tracking-widest text-[#d4a853] mb-4">Mapeamento Inteligente</h3>
         <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-3">
               <p className="text-xs text-slate-400 leading-relaxed">
                 O Vettus detecta automaticamente os campos da sua planilha. Certifique-se de que os cabeçalhos incluam termos como:
               </p>
               <div className="flex flex-wrap gap-2 mt-2">
                 {['Nome', 'Email', 'Telefone', 'Celular', 'Orçamento', 'Interesse'].map(tag => (
                   <span key={tag} className="px-2 py-1 bg-white/5 border border-white/10 rounded-md text-[10px] font-mono text-emerald-400">{tag}</span>
                 ))}
               </div>
            </div>
            <div className="space-y-4">
               <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 rounded-lg bg-[#d4a853]/20 flex items-center justify-center shrink-0">
                     <CheckCircle className="w-3.5 h-3.5 text-[#d4a853]" />
                  </div>
                  <p className="text-[11px] text-slate-300">Compatível com Excel 365, Google Sheets e arquivos CSV.</p>
               </div>
               <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 rounded-lg bg-[#d4a853]/20 flex items-center justify-center shrink-0">
                     <CheckCircle className="w-3.5 h-3.5 text-[#d4a853]" />
                  </div>
                  <p className="text-[11px] text-slate-300">Ideal para migração de outros CRMs ou portais imobiliários.</p>
               </div>
            </div>
         </div>
      </div>
    </div>
  );
};
