
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Peer } from 'peerjs';
import { Layout } from './components/Layout.tsx';
import { Dashboard } from './components/Dashboard.tsx';
import { PropertyView } from './components/Properties.tsx';
import { ClientView } from './components/Clients.tsx';
import { SalesView } from './components/Sales.tsx';
import { SpreadsheetsView } from './components/Spreadsheets.tsx';
import { ReminderView } from './components/Reminders.tsx';
import { ActivityView } from './components/Activities.tsx';
import { MarketingView } from './components/Marketing.tsx';
import { TasksView } from './components/Tasks.tsx';
import { BrokersView } from './components/Brokers.tsx';
import { Auth } from './components/Auth.tsx';
import { NewClientModal } from './components/NewClientModal.tsx';
import { NewPropertyModal } from './components/NewPropertyModal.tsx';
import { LeadImport } from './components/LeadImport.tsx'; 
import { Backup } from './components/Backup.tsx';
import { RefreshCw, Zap, AlertTriangle } from 'lucide-react';
import { Broker, Property, Client, Task, Activity, Reminder, Commission, PropertyStatus, AppView, ClientStatus, Campaign, SystemActivity } from './types.ts';
import { MOCK_BROKERS, MOCK_PROPERTIES, MOCK_CLIENTS, MOCK_TASKS, MOCK_ACTIVITIES, MOCK_REMINDERS, MOCK_COMMISSIONS, MOCK_CAMPAIGNS } from './constants.tsx';

const STORAGE_KEY_PREFIX = 'vettus_v3_core_';

const loadLocal = <T,>(key: string, def: T): T => {
  try {
    const val = localStorage.getItem(STORAGE_KEY_PREFIX + key);
    return val ? JSON.parse(val) : def;
  } catch { return def; }
};

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<Broker | null>(null);
  const [currentView, setCurrentView] = useState<AppView>('dashboard');
  const [isClientModalOpen, setIsClientModalOpen] = useState(false);
  const [clientToEdit, setClientToEdit] = useState<Client | null>(null);
  const [isPropertyModalOpen, setIsPropertyModalOpen] = useState(false);
  const [propertyToEdit, setPropertyToEdit] = useState<Property | null>(null);
  const [syncStatus, setSyncStatus] = useState<'synced' | 'syncing'>('synced');
  const [networkError, setNetworkError] = useState<string | null>(null);

  // Estados de Dados
  const [brokers, setBrokers] = useState<Broker[]>(() => loadLocal('brokers', MOCK_BROKERS) || []);
  const [properties, setProperties] = useState<Property[]>(() => loadLocal('properties', MOCK_PROPERTIES) || []);
  const [clients, setClients] = useState<Client[]>(() => loadLocal('clients', MOCK_CLIENTS) || []);
  const [tasks, setTasks] = useState<Task[]>(() => loadLocal('tasks', MOCK_TASKS) || []);
  const [activities, setActivities] = useState<Activity[]>(() => loadLocal('activities', MOCK_ACTIVITIES) || []);
  const [reminders, setReminders] = useState<Reminder[]>(() => loadLocal('reminders', MOCK_REMINDERS) || []);
  const [commissions, setCommissions] = useState<Commission[]>(() => loadLocal('commissions', MOCK_COMMISSIONS) || []);
  const [campaigns, setCampaigns] = useState<Campaign[]>(() => loadLocal('campaigns', MOCK_CAMPAIGNS) || []);
  const [systemLogs, setSystemLogs] = useState<SystemActivity[]>(() => loadLocal('systemLogs', []) || []);
  const [onlineBrokers, setOnlineBrokers] = useState<string[]>([]);

  const dataRef = useRef({ brokers, properties, clients, tasks, activities, reminders, commissions, campaigns, systemLogs });
  useEffect(() => {
    dataRef.current = { brokers, properties, clients, tasks, activities, reminders, commissions, campaigns, systemLogs };
  }, [brokers, properties, clients, tasks, activities, reminders, commissions, campaigns, systemLogs]);

  const handleExportBackup = useCallback((isAuto: boolean = false) => {
    const backup: Record<string, any> = {};
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith(STORAGE_KEY_PREFIX)) {
        try {
          backup[key] = JSON.parse(localStorage.getItem(key) || '{}');
        } catch {
          backup[key] = localStorage.getItem(key);
        }
      }
    }
    const dataStr = JSON.stringify(backup, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const dateStr = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    link.download = isAuto 
      ? `VETTUS_AUTO_BACKUP_${dateStr}.vettus`
      : `VETTUS_MANUAL_SNAPSHOT_${dateStr}.vettus`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    localStorage.setItem(STORAGE_KEY_PREFIX + 'last_backup_date', new Date().toISOString());
  }, []);

  useEffect(() => {
    const handleBeforeUnload = () => {
      handleExportBackup(true);
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [handleExportBackup]);

  const peerRef = useRef<Peer | null>(null);
  const activeConns = useRef<any[]>([]);

  const syncPayload = useCallback((payload: any) => {
    if (!payload) return;
    setSyncStatus('syncing');
    
    if (payload.brokers) setBrokers(curr => {
      const map = new Map((curr || []).map(b => [b.id, b]));
      payload.brokers.forEach((b: Broker) => map.set(b.id, b));
      return Array.from(map.values());
    });
    
    if (payload.properties) setProperties(curr => {
      const map = new Map((curr || []).map(p => [p.id, p]));
      payload.properties.forEach((p: Property) => map.set(p.id, p));
      return Array.from(map.values());
    });
    
    if (payload.clients) setClients(curr => {
      const map = new Map((curr || []).map(c => [c.id, c]));
      payload.clients.forEach((c: Client) => map.set(c.id, c));
      return Array.from(map.values());
    });

    if (payload.tasks) setTasks(curr => {
      const map = new Map((curr || []).map(t => [t.id, t]));
      payload.tasks.forEach((t: Task) => map.set(t.id, t));
      return Array.from(map.values());
    });

    if (payload.activities) setActivities(curr => {
      const map = new Map((curr || []).map(a => [a.id, a]));
      payload.activities.forEach((a: Activity) => map.set(a.id, a));
      return Array.from(map.values());
    });

    if (payload.reminders) setReminders(curr => {
      const map = new Map((curr || []).map(r => [r.id, r]));
      payload.reminders.forEach((r: Reminder) => map.set(r.id, r));
      return Array.from(map.values());
    });

    if (payload.commissions) setCommissions(curr => {
      const map = new Map((curr || []).map(co => [co.id, co]));
      payload.commissions.forEach((co: Commission) => map.set(co.id, co));
      return Array.from(map.values());
    });

    if (payload.systemLogs) setSystemLogs(curr => {
      const map = new Map<string, SystemActivity>((curr || []).map(l => [l.id, l]));
      payload.systemLogs.forEach((l: SystemActivity) => map.set(l.id, l));
      const sorted = Array.from(map.values()).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
      return sorted.slice(0, 100);
    });

    if (payload.deletedClientId) {
      setClients(curr => curr.filter(c => c.id !== payload.deletedClientId));
    }

    if (payload.deletedPropertyId) {
      setProperties(curr => curr.filter(p => p.id !== payload.deletedPropertyId));
    }
    
    setTimeout(() => setSyncStatus('synced'), 1000);
  }, []);

  const broadcast = useCallback((data: any) => {
    activeConns.current.forEach(conn => {
      if (conn && conn.open) {
        conn.send({ type: 'DATA_UPDATE', payload: data });
      }
    });
  }, []);

  const broadcastLog = useCallback((action: string, target: string) => {
    if (!currentUser) return;
    const log: SystemActivity = {
      id: Math.random().toString(36).substr(2, 9),
      brokerId: currentUser.id,
      brokerName: currentUser.name,
      action,
      target,
      timestamp: new Date().toISOString()
    };
    
    setSystemLogs(prev => [log, ...prev].slice(0, 100));
    broadcast({ systemLogs: [log] });
  }, [currentUser, broadcast]);

  useEffect(() => {
    if (!currentUser) return;
    const netId = (currentUser.networkId || 'VETTUS-PRO').replace(/[^a-zA-Z0-9]/g, '');
    const sessionSuffix = Math.random().toString(36).substring(7);
    const myId = currentUser.role === 'Admin' 
      ? `vettus-master-${netId}` 
      : `vettus-node-${currentUser.id}-${sessionSuffix}`;
    
    const peer = new Peer(myId, { debug: 1 });
    peerRef.current = peer;

    peer.on('open', () => {
      setNetworkError(null);
      if (currentUser.role === 'Broker') {
        const masterId = `vettus-master-${netId}`;
        const conn = peer.connect(masterId);
        setupConn(conn);
      }
    });

    peer.on('error', (err) => {
      if (err.type === 'id-taken' && currentUser.role === 'Admin') {
        setNetworkError('ID de Administrador em uso. Verifique outras abas.');
      }
    });

    peer.on('connection', setupConn);

    function setupConn(conn: any) {
      if (!conn) return;
      conn.on('open', () => {
        activeConns.current.push(conn);
        conn.send({ type: 'DATA_UPDATE', payload: dataRef.current });
        if (currentUser?.role === 'Admin') {
           const peerId = conn.peer;
           if (peerId.startsWith('vettus-node-')) {
             const bId = peerId.split('-')[2];
             setOnlineBrokers(prev => Array.from(new Set([...prev, bId])));
           }
        }
      });
      conn.on('data', (data: any) => {
        if (data && data.type === 'DATA_UPDATE') syncPayload(data.payload);
      });
      const cleanup = () => { 
        activeConns.current = activeConns.current.filter(c => c !== conn);
        if (currentUser?.role === 'Admin' && conn.peer.startsWith('vettus-node-')) {
          const bId = conn.peer.split('-')[2];
          setOnlineBrokers(prev => prev.filter(id => id !== bId));
        }
      };
      conn.on('close', cleanup);
      conn.on('error', cleanup);
    }
    return () => { peer.destroy(); activeConns.current = []; };
  }, [currentUser, syncPayload]);

  useEffect(() => {
    const timer = setTimeout(() => {
      try {
        localStorage.setItem(STORAGE_KEY_PREFIX + 'brokers', JSON.stringify(brokers));
        localStorage.setItem(STORAGE_KEY_PREFIX + 'properties', JSON.stringify(properties));
        localStorage.setItem(STORAGE_KEY_PREFIX + 'clients', JSON.stringify(clients));
        localStorage.setItem(STORAGE_KEY_PREFIX + 'tasks', JSON.stringify(tasks));
        localStorage.setItem(STORAGE_KEY_PREFIX + 'activities', JSON.stringify(activities));
        localStorage.setItem(STORAGE_KEY_PREFIX + 'reminders', JSON.stringify(reminders));
        localStorage.setItem(STORAGE_KEY_PREFIX + 'commissions', JSON.stringify(commissions));
        localStorage.setItem(STORAGE_KEY_PREFIX + 'campaigns', JSON.stringify(campaigns));
        localStorage.setItem(STORAGE_KEY_PREFIX + 'systemLogs', JSON.stringify(systemLogs));
      } catch (e) { console.error(e); }
    }, 2000);
    return () => clearTimeout(timer);
  }, [brokers, properties, clients, tasks, activities, reminders, commissions, campaigns, systemLogs]);

  const filterData = useCallback(<T extends { brokerId?: string }>(list: T[], isProperty: boolean = false) => {
    if (!currentUser) return [];
    const safeList = list || [];
    if (isProperty) return safeList;
    return currentUser.role === 'Admin' ? safeList : safeList.filter(i => i.brokerId === currentUser.id);
  }, [currentUser]);

  const stats = {
    properties: filterData(properties, true),
    clients: filterData(clients),
    tasks: filterData(tasks),
    activities: filterData(activities),
    reminders: filterData(reminders),
    commissions: filterData(commissions),
    campaigns: filterData(campaigns),
    systemLogs: systemLogs,
    onlineBrokers: onlineBrokers
  };

  const handleAddClient = (c: Client) => {
    const updated = [...(clients || []), { ...c, updatedAt: new Date().toISOString() }];
    setClients(updated);
    setIsClientModalOpen(false);
    setClientToEdit(null);
    broadcast({ clients: updated });
    broadcastLog('Adicionou Cliente', c.name);
  };

  const handleUpdateClient = (c: Client) => {
    const updated = (clients || []).map(i => i.id === c.id ? { ...c, updatedAt: new Date().toISOString() } : i);
    setClients(updated);
    setIsClientModalOpen(false);
    setClientToEdit(null);
    broadcast({ clients: updated });
    broadcastLog('Atualizou Cliente', c.name);
  };

  const handleDeleteClient = (id: string) => {
    if (currentUser?.role !== 'Admin') return;
    const client = clients.find(c => c.id === id);
    const updated = (clients || []).filter(c => c.id !== id);
    setClients(updated);
    broadcast({ deletedClientId: id });
    broadcastLog('Excluiu Cliente', client?.name || id);
  };

  const handleImportLeads = (newLeads: Client[]) => {
    const updated = [...(clients || []), ...newLeads];
    setClients(updated);
    broadcast({ clients: updated });
    broadcastLog('Importou Leads', `${newLeads.length} contatos`);
    setCurrentView('clients'); 
  };

  const handleAddProperty = (p: Property) => {
    const updated = [...(properties || []), { ...p, updatedAt: new Date().toISOString() }];
    setProperties(updated);
    setIsPropertyModalOpen(false);
    broadcast({ properties: updated });
    broadcastLog('Captou Imóvel', p.title);
  };

  const handleUpdateProperty = (p: Property) => {
    const updated = (properties || []).map(i => i.id === p.id ? { ...p, updatedAt: new Date().toISOString() } : i);
    setProperties(updated);
    setIsPropertyModalOpen(false);
    setPropertyToEdit(null);
    broadcast({ properties: updated });
    broadcastLog('Editou Imóvel', p.title);
  };

  const handleDeleteProperty = (id: string) => {
    if (currentUser?.role !== 'Admin') return;
    const property = properties.find(p => p.id === id);
    const updated = (properties || []).filter(p => p.id !== id);
    setProperties(updated);
    broadcast({ deletedPropertyId: id });
    broadcastLog('Excluiu Imóvel', property?.title || id);
  };

  const handleUpdateTask = (t: Task) => {
    const updated = (tasks || []).map(i => i.id === t.id ? { ...t, updatedAt: new Date().toISOString() } : i);
    setTasks(updated);
    broadcast({ tasks: updated });
    broadcastLog('Moveu no Funil', `${t.clientName} -> ${t.stage}`);
  };

  const handleAddActivity = (a: Activity) => {
    const updated = [a, ...(activities || [])];
    setActivities(updated);
    broadcast({ activities: updated });
    broadcastLog('Registrou Atividade', `${a.type} com ${a.clientName}`);
  };

  const handleAddSale = (s: Commission) => {
    const updated = [s, ...(commissions || [])];
    setCommissions(updated);
    broadcast({ commissions: updated });
    broadcastLog('Venda Realizada!', `${s.propertyTitle} para ${s.clientName}`);
  };

  if (!currentUser) return <Auth onLogin={setCurrentUser} onRegister={b => setBrokers(p => [...p, b])} existingBrokers={brokers || []} />;

  return (
    <>
      <div className="fixed top-4 right-8 z-[200] flex flex-col items-end space-y-2 pointer-events-auto">
        {networkError && (
          <div className="bg-red-500 text-white px-4 py-2 rounded-xl text-[10px] font-black uppercase flex items-center shadow-lg border border-red-600">
            <AlertTriangle className="w-3 h-3 mr-2" />
            {networkError}
          </div>
        )}
        <div className={`flex items-center space-x-2 px-4 py-2 rounded-full backdrop-blur-md border text-[10px] font-black uppercase tracking-widest transition-all shadow-xl ${
          syncStatus === 'synced' ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' : 'bg-[#d4a853]/10 text-[#d4a853] border-[#d4a853]/20 animate-pulse'
        }`}>
          {syncStatus === 'synced' ? <Zap className="w-3.5 h-3.5" /> : <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
          <span>{syncStatus === 'synced' ? 'Rede Estável' : 'Sincronizando...'}</span>
        </div>
        {currentUser.role === 'Admin' && onlineBrokers.length > 0 && (
           <div className="bg-blue-600 text-white px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest animate-pulse shadow-lg">
              {onlineBrokers.length} Corretores Online
           </div>
        )}
      </div>

      <Layout 
        currentView={currentView} 
        onViewChange={setCurrentView} 
        currentUser={currentUser} 
        onLogout={() => setCurrentUser(null)}
        pendingRemindersCount={(stats.reminders || []).filter(r => !r.completed).length}
      >
        {currentView === 'dashboard' && <Dashboard onNavigate={setCurrentView} statsData={stats} currentUser={currentUser} />}
        {currentView === 'lead_import' && <LeadImport currentUser={currentUser} onImportLeads={handleImportLeads} />}
        {currentView === 'backup' && <Backup currentUser={currentUser} onManualBackup={() => handleExportBackup(false)} />}
        {currentView === 'properties' && (
          <PropertyView 
            properties={stats.properties} 
            onAddProperty={handleAddProperty} 
            onEditProperty={(p) => { setPropertyToEdit(p); setIsPropertyModalOpen(true); }}
            onDeleteProperty={handleDeleteProperty}
            currentUser={currentUser} 
            brokers={brokers || []} 
            availableTypes={['Casa', 'Apartamento', 'Terreno', 'Cobertura', 'Comercial']} 
            availableStatuses={[PropertyStatus.AVAILABLE, PropertyStatus.RESERVED, PropertyStatus.SOLD]} 
            onAddType={()=>{}} 
            onAddStatus={()=>{}} 
            onOpenAddModal={() => { setPropertyToEdit(null); setIsPropertyModalOpen(true); }}
          />
        )}
        {currentView === 'clients' && (
          <ClientView 
            clients={stats.clients} 
            // Liberamos TODAS as atividades para o histórico global no atendimento individual
            activities={activities} 
            properties={properties}
            onAddClient={handleAddClient} 
            onUpdateClient={handleUpdateClient} 
            onDeleteClient={handleDeleteClient}
            onEditClient={(c) => { setClientToEdit(c); setIsClientModalOpen(true); }}
            onAddActivity={handleAddActivity} 
            onAddSale={handleAddSale}
            onUpdateProperty={handleUpdateProperty}
            currentUser={currentUser} 
            brokers={brokers || []} 
            onOpenAddModal={() => { setClientToEdit(null); setIsClientModalOpen(true); }}
            onOpenImport={() => setCurrentView('lead_import')}
          />
        )}
        {currentView === 'sales' && <SalesView sales={stats.commissions} brokers={brokers || []} />}
        {currentView === 'spreadsheets' && <SpreadsheetsView brokers={brokers || []} clients={stats.clients} commissions={stats.commissions} properties={stats.properties} />}
        {currentView === 'reminders' && <ReminderView reminders={stats.reminders} onToggleReminder={id => { const updated = (reminders || []).map(r => r.id === id ? {...r, completed: !r.completed} : r); setReminders(updated); broadcast({reminders: updated}); }} />}
        {currentView === 'activities' && <ActivityView activities={stats.activities} onAddActivity={handleAddActivity} onAddReminder={r => { const updated = [...(reminders || []), r]; setReminders(updated); broadcast({reminders: updated}); }} currentUser={currentUser} clients={stats.clients} />}
        {currentView === 'marketing' && <MarketingView campaigns={stats.campaigns} />}
        {currentView === 'tasks' && <TasksView tasks={stats.tasks} currentUser={currentUser} onUpdateTask={handleUpdateTask} onAddActivity={handleAddActivity} />}
        {currentView === 'brokers' && (
          <BrokersView 
            brokers={brokers || []} 
            onAddBroker={b => { 
              const updated = [...(brokers || []), b]; 
              setBrokers(updated); 
              broadcast({brokers: updated}); 
            }} 
            onUpdateBroker={b => { 
              const updated = (brokers || []).map(i => i.id === b.id ? b : i);
              setBrokers(updated); 
              broadcast({brokers: updated}); 
            }} 
            onDeleteBroker={id => { 
              const updated = (brokers || []).filter(b => b.id !== id);
              setBrokers(updated); 
              broadcast({brokers: updated}); 
            }} 
            currentUser={currentUser} 
          />
        )}
      </Layout>
      
      <NewClientModal 
        isOpen={isClientModalOpen} 
        onClose={() => { setIsClientModalOpen(false); setClientToEdit(null); }} 
        onAddClient={handleAddClient} 
        onUpdateClient={handleUpdateClient}
        clientToEdit={clientToEdit}
        currentUser={currentUser} 
        brokers={brokers || []} 
      />
      
      <NewPropertyModal 
        isOpen={isPropertyModalOpen} 
        onClose={() => { setIsPropertyModalOpen(false); setPropertyToEdit(null); }} 
        onAddProperty={handleAddProperty} 
        onUpdateProperty={handleUpdateProperty}
        propertyToEdit={propertyToEdit}
        currentUser={currentUser} 
        brokers={brokers || []} 
        availableTypes={['Casa', 'Apartamento', 'Terreno', 'Cobertura', 'Comercial']} 
        availableStatuses={[PropertyStatus.AVAILABLE, PropertyStatus.RESERVED, PropertyStatus.SOLD]} 
      />
    </>
  );
};

export default App;
