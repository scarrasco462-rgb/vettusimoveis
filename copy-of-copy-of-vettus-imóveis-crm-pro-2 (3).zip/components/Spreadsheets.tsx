
import React, { useState } from 'react';
import { 
  TableProperties, 
  Users, 
  BadgeDollarSign, 
  TrendingUp, 
  PieChart, 
  Download, 
  Search, 
  Printer,
  Clock,
  Building2,
  Table as TableIcon,
  FileSpreadsheet
} from 'lucide-react';
import { Broker, Client, Commission, Property, ClientStatus } from '../types';

interface SpreadsheetsViewProps {
  brokers: Broker[];
  clients: Client[];
  commissions: Commission[];
  properties: Property[];
}

type SpreadsheetTab = 'clients' | 'sales' | 'performance' | 'leads';

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 2,
  }).format(value);
};

export const SpreadsheetsView: React.FC<SpreadsheetsViewProps> = ({ brokers, clients, commissions, properties }) => {
  const [activeTab, setActiveTab] = useState<SpreadsheetTab>('clients');
  const [searchTerm, setSearchTerm] = useState('');

  const getBrokerName = (id: string) => brokers.find(b => b.id === id)?.name || 'Desconhecido';

  const handlePrint = () => {
    window.print();
  };

  const handleExportCSV = () => {
    let dataToExport: any[][] = [];
    let headers: string[] = [];
    const filename = `vettus_relatorio_${activeTab}_${new Date().toISOString().split('T')[0]}.csv`;

    if (activeTab === 'clients') {
      headers = ['Corretor', 'Cliente', 'Email', 'Telefone', 'Status', 'Orcamento', 'Ultimo Contato'];
      dataToExport = clients
        .filter(c => c.name.toLowerCase().includes(searchTerm.toLowerCase()))
        .map(c => [getBrokerName(c.brokerId), c.name, c.email, c.phone, c.status, c.budget, c.lastContact]);
    } else if (activeTab === 'sales') {
      headers = ['Corretor', 'Imovel', 'Data Venda', 'Cliente', 'Comissao'];
      dataToExport = commissions
        .filter(s => s.propertyTitle.toLowerCase().includes(searchTerm.toLowerCase()))
        .map(s => [getBrokerName(s.brokerId), s.propertyTitle, s.date, s.clientName, s.amount]);
    } else if (activeTab === 'performance') {
      headers = ['Membro', 'Carteira Ativa', 'Fechamentos', 'Conversao %', 'Volume Total', 'Score'];
      dataToExport = brokers.map(broker => {
        const bSales = commissions.filter(c => c.brokerId === broker.id);
        const total = bSales.reduce((acc, c) => acc + c.amount, 0);
        const bClients = clients.filter(c => c.brokerId === broker.id).length;
        const conv = bClients > 0 ? (bSales.length / bClients * 100).toFixed(1) : '0.0';
        return [broker.name, bClients, bSales.length, conv, total, broker.performance];
      });
    } else if (activeTab === 'leads') {
      headers = ['Corretor', 'Quente', 'Morno', 'Frio', 'Primeiro Contato', 'Total'];
      dataToExport = brokers.map(broker => {
        const bClients = clients.filter(c => c.brokerId === broker.id);
        return [
          broker.name,
          bClients.filter(c => c.status === ClientStatus.HOT).length,
          bClients.filter(c => c.status === ClientStatus.WARM).length,
          bClients.filter(c => c.status === ClientStatus.COLD).length,
          bClients.filter(c => c.status === ClientStatus.FIRST_CONTACT).length,
          bClients.length
        ];
      });
    }

    const csvContent = [
      headers.join(','),
      ...dataToExport.map(row => row.map(val => `"${String(val).replace(/"/g, '""')}"`).join(','))
    ].join('\n');

    const blob = new Blob(["\uFEFF" + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getActiveReportTitle = () => {
    switch(activeTab) {
      case 'clients': return 'Atendimento Individual de Clientes';
      case 'sales': return 'Consolidado de Vendas por Corretor';
      case 'performance': return 'Métricas de Desempenho Operacional';
      case 'leads': return 'Status e Matriz de Temperatura de Leads';
    }
  };

  const renderClientsSpreadsheet = () => (
    <div className="bg-white rounded-3xl border border-slate-100 shadow-xl overflow-hidden printable-area">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50 text-slate-400 text-[10px] font-black uppercase tracking-[0.2em] border-b border-slate-100">
              <th className="px-8 py-5">Corretor</th>
              <th className="px-8 py-5">Cliente</th>
              <th className="px-8 py-5">Status</th>
              <th className="px-8 py-5">Orçamento</th>
              <th className="px-8 py-5">Último Contato</th>
              <th className="px-8 py-5">Próxima Ação</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {clients.filter(c => c.name.toLowerCase().includes(searchTerm.toLowerCase()) || getBrokerName(c.brokerId).toLowerCase().includes(searchTerm.toLowerCase())).map((client) => (
              <tr key={client.id} className="hover:bg-slate-50/50 transition-colors group">
                <td className="px-8 py-5">
                  <span className="text-xs font-bold text-slate-700">{getBrokerName(client.brokerId)}</span>
                </td>
                <td className="px-8 py-5">
                  <span className="text-xs font-bold text-slate-900">{client.name}</span>
                </td>
                <td className="px-8 py-5">
                   <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-widest border ${
                    client.status === ClientStatus.HOT ? 'bg-red-50 text-red-600 border-red-100' :
                    client.status === ClientStatus.WARM ? 'bg-orange-50 text-orange-600 border-orange-100' :
                    'bg-blue-50 text-blue-600 border-blue-100'
                  }`}>
                    {client.status}
                  </span>
                </td>
                <td className="px-8 py-5">
                  <span className="text-xs font-mono font-bold text-slate-600">{formatCurrency(client.budget)}</span>
                </td>
                <td className="px-8 py-5">
                  <span className="text-xs text-slate-500">{new Date(client.lastContact).toLocaleDateString('pt-BR')}</span>
                </td>
                <td className="px-8 py-5">
                  <div className="flex items-center text-xs text-[#d4a853] font-bold">
                    <Clock className="w-3 h-3 mr-1 no-print" />
                    {client.nextActivityDate ? new Date(client.nextActivityDate).toLocaleDateString('pt-BR') : 'Pendente'}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderSalesSpreadsheet = () => (
    <div className="bg-white rounded-3xl border border-slate-100 shadow-xl overflow-hidden printable-area">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50 text-slate-400 text-[10px] font-black uppercase tracking-[0.2em] border-b border-slate-100">
              <th className="px-8 py-5">Corretor</th>
              <th className="px-8 py-5">Imóvel</th>
              <th className="px-8 py-5">Data Venda</th>
              <th className="px-8 py-5">Cliente</th>
              <th className="px-8 py-5 text-right">Comissão Vettus</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {commissions.filter(sale => sale.propertyTitle.toLowerCase().includes(searchTerm.toLowerCase()) || getBrokerName(sale.brokerId).toLowerCase().includes(searchTerm.toLowerCase())).map((sale) => (
              <tr key={sale.id} className="hover:bg-slate-50/50 transition-colors group">
                <td className="px-8 py-5">
                  <span className="text-xs font-bold text-slate-700">{getBrokerName(sale.brokerId)}</span>
                </td>
                <td className="px-8 py-5">
                  <div className="flex items-center text-xs text-slate-900 font-medium">
                    <Building2 className="w-3.5 h-3.5 mr-2 text-[#d4a853] no-print" />
                    {sale.propertyTitle}
                  </div>
                </td>
                <td className="px-8 py-5 text-xs text-slate-500">
                  {new Date(sale.date).toLocaleDateString('pt-BR')}
                </td>
                <td className="px-8 py-5 text-xs font-bold text-slate-600">{sale.clientName}</td>
                <td className="px-8 py-5 text-right font-mono text-sm font-black text-slate-900">
                  {formatCurrency(sale.amount)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderPerformanceSpreadsheet = () => {
    const performanceData = brokers.map(broker => {
      const bSales = commissions.filter(c => c.brokerId === broker.id);
      const total = bSales.reduce((acc, c) => acc + c.amount, 0);
      const bClients = clients.filter(c => c.brokerId === broker.id).length;
      return {
        ...broker,
        salesCount: bSales.length,
        totalFaturado: total,
        activeClients: bClients,
        conversionRate: bClients > 0 ? (bSales.length / bClients * 100).toFixed(1) : '0.0'
      };
    }).filter(b => b.name.toLowerCase().includes(searchTerm.toLowerCase()));

    return (
      <div className="bg-white rounded-3xl border border-slate-100 shadow-xl overflow-hidden printable-area">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-400 text-[10px] font-black uppercase tracking-[0.2em] border-b border-slate-100">
                <th className="px-8 py-5">Membro da Equipe</th>
                <th className="px-8 py-5 text-center">Carteira Ativa</th>
                <th className="px-8 py-5 text-center">Fechamentos</th>
                <th className="px-8 py-5 text-center">Conversão (%)</th>
                <th className="px-8 py-5 text-right">Volume Total</th>
                <th className="px-8 py-5 text-right">Score Vettus</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {performanceData.map((data) => (
                <tr key={data.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-8 py-5 font-bold text-slate-900 text-xs">{data.name}</td>
                  <td className="px-8 py-5 text-center text-xs font-medium text-slate-600">{data.activeClients}</td>
                  <td className="px-8 py-5 text-center text-xs font-medium text-slate-600">{data.salesCount}</td>
                  <td className="px-8 py-5 text-center font-black text-[#d4a853] text-xs">
                    {data.conversionRate}%
                  </td>
                  <td className="px-8 py-5 text-right font-mono text-xs font-bold text-slate-900">{formatCurrency(data.totalFaturado)}</td>
                  <td className="px-8 py-5 text-right">
                    <span className="px-3 py-1 bg-slate-900 text-[#d4a853] rounded-lg text-[10px] font-black uppercase tracking-tighter shadow-sm border border-[#d4a853]/20">
                      {data.performance}%
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  const renderLeadsSpreadsheet = () => {
    const leadStats = brokers.map(broker => {
      const bClients = clients.filter(c => c.brokerId === broker.id);
      return {
        name: broker.name,
        hot: bClients.filter(c => c.status === ClientStatus.HOT).length,
        warm: bClients.filter(c => c.status === ClientStatus.WARM).length,
        cold: bClients.filter(c => c.status === ClientStatus.COLD).length,
        firstContact: bClients.filter(c => c.status === ClientStatus.FIRST_CONTACT).length,
        total: bClients.length
      };
    }).filter(b => b.name.toLowerCase().includes(searchTerm.toLowerCase()));

    return (
      <div className="bg-white rounded-3xl border border-slate-100 shadow-xl overflow-hidden printable-area">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-400 text-[10px] font-black uppercase tracking-[0.2em] border-b border-slate-100">
                <th className="px-8 py-5">Corretor</th>
                <th className="px-8 py-5 text-center">🔥 Quente (HOT)</th>
                <th className="px-8 py-5 text-center">⚡ Morno (WARM)</th>
                <th className="px-8 py-5 text-center">❄️ Frio (COLD)</th>
                <th className="px-8 py-5 text-center">📩 Primeiro Contato</th>
                <th className="px-8 py-5 text-right">Total Base</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {leadStats.map((stat, i) => (
                <tr key={i} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-8 py-5 font-bold text-slate-900 text-xs">{stat.name}</td>
                  <td className="px-8 py-5 text-center">
                    <span className="text-xs font-black text-red-500 bg-red-50 px-3 py-1 rounded-full">{stat.hot}</span>
                  </td>
                  <td className="px-8 py-5 text-center">
                    <span className="text-xs font-black text-orange-500 bg-orange-50 px-3 py-1 rounded-full">{stat.warm}</span>
                  </td>
                  <td className="px-8 py-5 text-center">
                    <span className="text-xs font-black text-green-500 bg-green-50 px-3 py-1 rounded-full">{stat.cold}</span>
                  </td>
                  <td className="px-8 py-5 text-center">
                    <span className="text-xs font-black text-blue-500 bg-blue-50 px-3 py-1 rounded-full">{stat.firstContact}</span>
                  </td>
                  <td className="px-8 py-5 text-right font-black text-slate-900 text-xs">{stat.total}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 no-print">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 flex items-center">
            <TableProperties className="w-6 h-6 mr-3 text-[#d4a853]" />
            Centro de Planilhas Analíticas
          </h1>
          <p className="text-slate-500 text-sm mt-1">Gestão de dados brutos e performance operacional da rede Vettus.</p>
        </div>
        <div className="flex items-center space-x-3">
          <div className="bg-white border border-slate-200 rounded-xl px-4 py-2 flex items-center space-x-3 shadow-sm focus-within:ring-2 focus-within:ring-[#d4a853]/50 transition-all">
            <Search className="w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              placeholder="Filtrar dados..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-transparent border-none outline-none text-xs w-48 font-medium text-slate-900" 
            />
          </div>
          <button 
            onClick={handlePrint}
            className="bg-[#0f172a] text-white px-5 py-2.5 rounded-xl text-xs font-bold flex items-center space-x-2 shadow-lg hover:bg-slate-800 transition-all active:scale-95"
          >
            <Printer className="w-4 h-4 text-[#d4a853]" />
            <span>Imprimir</span>
          </button>
          <button 
            onClick={handleExportCSV}
            className="gold-gradient text-white px-5 py-2.5 rounded-xl text-xs font-bold flex items-center space-x-2 shadow-lg shadow-yellow-600/20 hover:scale-105 transition-all active:scale-95"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Exportar CSV</span>
          </button>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 bg-slate-100 p-1 rounded-2xl w-fit no-print">
        {[
          { id: 'clients', label: 'Clientes', icon: Users },
          { id: 'sales', label: 'Vendas', icon: BadgeDollarSign },
          { id: 'performance', label: 'Desempenho', icon: TrendingUp },
          { id: 'leads', label: 'Status Leads', icon: PieChart },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as SpreadsheetTab)}
            className={`flex items-center space-x-2 px-6 py-2.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === tab.id 
              ? 'bg-[#0f172a] text-white shadow-lg' 
              : 'text-slate-500 hover:bg-white hover:text-slate-900'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      <div className="space-y-4">
        <div className="flex items-center space-x-4">
          <h2 className="text-[10px] font-black text-[#d4a853] uppercase tracking-[0.3em] ml-2">
            Relatório Ativo: {getActiveReportTitle()}
          </h2>
          <div className="h-px flex-1 bg-gradient-to-r from-yellow-200 to-transparent no-print"></div>
        </div>

        {activeTab === 'clients' && renderClientsSpreadsheet()}
        {activeTab === 'sales' && renderSalesSpreadsheet()}
        {activeTab === 'performance' && renderPerformanceSpreadsheet()}
        {activeTab === 'leads' && renderLeadsSpreadsheet()}
      </div>

      <style>{`
        @media print {
          body { 
            background: white !important; 
            color: black !important;
            margin: 0 !important;
            padding: 20px !important;
          }
          .no-print { display: none !important; }
          main { 
            margin-left: 0 !important; 
            padding: 0 !important; 
            width: 100% !important;
          }
          aside, header { display: none !important; }
          .printable-area { 
            box-shadow: none !important; 
            border: 1px solid #000 !important;
            border-radius: 0 !important;
            overflow: visible !important;
          }
          table { 
            width: 100% !important; 
            border-collapse: collapse !important; 
            table-layout: auto !important;
          }
          th { 
            background-color: #f8fafc !important; 
            color: #000 !important; 
            border: 1px solid #000 !important;
            -webkit-print-color-adjust: exact;
          }
          td { 
            border: 1px solid #000 !important; 
            padding: 8px !important; 
            font-size: 10px !important; 
            color: #000 !important;
          }
          tr { page-break-inside: avoid !important; }
          h2 { 
            color: #000 !important; 
            margin-bottom: 15px !important; 
            font-size: 14px !important;
            text-align: center;
          }
          /* Custom print header */
          body::before {
            content: "VETTUS IMÓVEIS - RELATÓRIO OFICIAL";
            display: block;
            text-align: center;
            font-weight: bold;
            font-size: 18px;
            margin-bottom: 20px;
            border-bottom: 2px solid #000;
            padding-bottom: 10px;
          }
        }
      `}</style>
    </div>
  );
};
