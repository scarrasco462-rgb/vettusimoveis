
import React, { useState, useEffect } from 'react';
import { Shield, User, Plus, Trash2, Key, Globe, Download, Square, Calendar, ShieldCheck as ShieldIcon, Lock, Unlock, X, CheckSquare, Pencil, Save } from 'lucide-react';
import { Broker, UserRole, AppView, ALL_PERMISSIONS } from '../types.ts';

interface BrokersViewProps {
  brokers: Broker[];
  onAddBroker: (broker: Broker) => void;
  onUpdateBroker: (broker: Broker) => void;
  onDeleteBroker: (id: string) => void;
  currentUser: Broker;
}

const MODULES: { id: AppView; label: string }[] = [
  { id: 'dashboard', label: 'Painel Geral' },
  { id: 'lead_import', label: 'Importação de Leads' },
  { id: 'tasks', label: 'Funil de Vendas' },
  { id: 'properties', label: 'Imóveis' },
  { id: 'clients', label: 'Clientes' },
  { id: 'marketing', label: 'Marketing AI' },
  { id: 'sales', label: 'Relatórios de Vendas' },
  { id: 'spreadsheets', label: 'Planilhas' },
  { id: 'activities', label: 'Agenda' },
  { id: 'reminders', label: 'Lembretes' }
];

export const BrokersView: React.FC<BrokersViewProps> = ({ brokers, onAddBroker, onUpdateBroker, onDeleteBroker, currentUser }) => {
  const [showModal, setShowModal] = useState(false);
  const [editingBroker, setEditingBroker] = useState<Broker | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    role: 'Broker' as UserRole,
    permissions: ['dashboard', 'tasks', 'properties', 'clients', 'activities', 'reminders'] as AppView[]
  });

  useEffect(() => {
    if (editingBroker) {
      setFormData({
        name: editingBroker.name,
        email: editingBroker.email,
        password: editingBroker.password || '',
        role: editingBroker.role,
        permissions: editingBroker.permissions || []
      });
    } else {
      setFormData({
        name: '',
        email: '',
        password: '',
        role: 'Broker',
        permissions: ['dashboard', 'tasks', 'properties', 'clients', 'activities', 'reminders']
      });
    }
  }, [editingBroker]);

  const togglePermission = (perm: AppView) => {
    setFormData(prev => {
      const newPerms = prev.permissions.includes(perm)
        ? prev.permissions.filter(p => p !== perm)
        : [...prev.permissions, perm];
      return { ...prev, permissions: newPerms };
    });
  };

  const handleEdit = (broker: Broker) => {
    setEditingBroker(broker);
    setShowModal(true);
  };

  const handleAddNew = () => {
    setEditingBroker(null);
    setShowModal(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingBroker) {
      const updatedBroker: Broker = {
        ...editingBroker,
        name: formData.name,
        email: formData.email.toLowerCase(),
        password: formData.password,
        role: formData.role,
        permissions: formData.role === 'Admin' ? ALL_PERMISSIONS : formData.permissions
      };
      onUpdateBroker(updatedBroker);
    } else {
      const newBroker: Broker = {
        id: Math.random().toString(36).substr(2, 9),
        name: formData.name,
        email: formData.email.toLowerCase(),
        password: formData.password,
        role: formData.role,
        joinDate: new Date().toISOString().split('T')[0],
        performance: 0,
        networkId: currentUser.networkId,
        blocked: false,
        permissions: formData.role === 'Admin' ? ALL_PERMISSIONS : formData.permissions
      };
      onAddBroker(newBroker);
    }
    setShowModal(false);
  };

  const handleToggleBlock = (broker: Broker) => {
    if (broker.id === currentUser.id) return;
    onUpdateBroker({ ...broker, blocked: !broker.blocked });
  };

  const handleDelete = (id: string) => {
    if (id === currentUser.id) return;
    if (confirm('Deseja realmente REMOVER este corretor da rede?')) {
      onDeleteBroker(id);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Gestão de Equipe</h1>
          <p className="text-slate-500">Controle total sobre corretores, acessos e performance da rede.</p>
        </div>
        <div className="flex items-center space-x-3">
          <button 
            onClick={handleAddNew}
            className="gold-gradient text-white px-6 py-3 rounded-xl flex items-center space-x-2 text-sm font-bold shadow-lg hover:scale-105 transition-transform"
          >
            <Plus className="w-5 h-5" />
            <span>Adicionar Corretor</span>
          </button>
        </div>
      </div>

      <div className="bg-[#0f172a] rounded-3xl p-8 border border-white/5 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-[#d4a853]/10 rounded-full blur-[80px] -mr-32 -mt-32"></div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center space-x-4">
             <div className="w-16 h-16 gold-gradient rounded-2xl flex items-center justify-center shadow-2xl">
                <Globe className="w-8 h-8 text-white animate-pulse" />
             </div>
             <div>
                <h3 className="text-white text-lg font-bold">Configurações de Rede</h3>
                <p className="text-slate-400 text-xs mt-1">ID da Imobiliária: <span className="text-[#d4a853] font-mono">{currentUser.networkId}</span></p>
             </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {brokers.map(broker => (
          <div key={broker.id} className={`bg-white rounded-2xl border p-6 shadow-sm hover:shadow-md transition-all relative overflow-hidden ${broker.blocked ? 'border-red-200 bg-red-50/10' : 'border-slate-100'}`}>
            <div className={`absolute top-0 right-0 w-1.5 h-full ${broker.blocked ? 'bg-red-500' : (broker.role === 'Admin' ? 'bg-[#d4a853]' : 'bg-slate-200')}`}></div>
            
            <div className="flex items-start justify-between mb-4">
              <div className={`w-14 h-14 rounded-xl flex items-center justify-center font-bold text-lg ${broker.blocked ? 'bg-red-100 text-red-600' : 'bg-slate-50 border border-slate-100 text-[#d4a853]'}`}>
                {broker.name[0]}
              </div>
              <div className="flex items-center space-x-2">
                <span className={`px-2 py-0.5 rounded-full text-[8px] font-black uppercase tracking-widest ${
                  broker.role === 'Admin' ? 'bg-yellow-50 text-[#d4a853]' : 'bg-slate-50 text-slate-500'
                }`}>
                  {broker.role}
                </span>
              </div>
            </div>

            <h3 className={`text-base font-bold truncate ${broker.blocked ? 'text-red-900 line-through opacity-60' : 'text-slate-900'}`}>{broker.name}</h3>
            <p className="text-[11px] text-slate-400 mb-4 truncate">{broker.email}</p>
            
            <div className="flex flex-wrap gap-1 mb-6 h-12 overflow-hidden content-start">
               {(broker.permissions || []).slice(0, 4).map(p => {
                 const mod = MODULES.find(m => m.id === p);
                 return mod ? (
                   <span key={p} className="text-[7px] font-black bg-slate-100 text-slate-400 px-1.5 py-0.5 rounded uppercase tracking-tighter">
                     {mod.label}
                   </span>
                 ) : null;
               })}
               {(broker.permissions?.length || 0) > 4 && <span className="text-[7px] font-black text-slate-300 px-1.5 py-0.5">+{(broker.permissions?.length || 0) - 4}</span>}
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-slate-50">
               <div className="flex flex-col">
                  <span className="text-[7px] font-black uppercase text-slate-300 tracking-widest">Membro desde</span>
                  <span className="text-[9px] font-bold text-slate-500">{broker.joinDate}</span>
               </div>
               <div className="flex items-center space-x-1.5">
                 {currentUser.role === 'Admin' && (
                   <>
                    <button 
                      onClick={() => handleEdit(broker)}
                      className="p-2 bg-slate-50 text-slate-400 border border-slate-100 rounded-lg hover:bg-[#d4a853]/10 hover:text-[#d4a853] transition-all"
                      title="Editar Perfil"
                    >
                      <Pencil className="w-3.5 h-3.5" />
                    </button>
                    {broker.id !== currentUser.id && (
                      <>
                        <button 
                          onClick={() => handleToggleBlock(broker)}
                          className={`p-2 rounded-lg transition-all border ${broker.blocked ? 'bg-emerald-50 text-emerald-600 border-emerald-100 hover:bg-emerald-100' : 'bg-red-50 text-red-600 border-red-100 hover:bg-red-100'}`}
                          title={broker.blocked ? "Desbloquear" : "Bloquear"}
                        >
                          {broker.blocked ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                        </button>
                        <button 
                          onClick={() => handleDelete(broker.id)}
                          className="p-2 bg-slate-50 text-slate-400 border border-slate-100 rounded-lg hover:bg-red-600 hover:text-white transition-all"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </>
                    )}
                   </>
                 )}
               </div>
            </div>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-[#0f172a]/70 backdrop-blur-md" onClick={() => setShowModal(false)}></div>
          <div className="bg-white w-full max-w-2xl rounded-[2.5rem] p-0 relative z-10 shadow-2xl animate-in zoom-in duration-300 overflow-hidden">
            <div className="navy-gradient p-8 text-white flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold uppercase tracking-tight">{editingBroker ? 'Atualizar Corretor' : 'Cadastrar na Rede'}</h2>
                <p className="text-slate-400 text-xs mt-1">{editingBroker ? `Editando perfil de ${editingBroker.name}` : 'Novo acesso master ou operacional'}</p>
              </div>
              <button onClick={() => setShowModal(false)} className="p-2 hover:bg-white/10 rounded-full transition-colors">
                <X className="w-6 h-6 text-white" />
              </button>
            </div>
            <form onSubmit={handleSave} className="p-8 bg-slate-50 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase ml-1">Nome Completo</label>
                    <input type="text" required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full bg-white border border-slate-200 rounded-xl py-3 px-4 text-sm font-bold text-slate-900 outline-none focus:ring-2 focus:ring-[#d4a853]/50 shadow-sm" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase ml-1">E-mail Institucional</label>
                    <input type="email" required value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} className="w-full bg-white border border-slate-200 rounded-xl py-3 px-4 text-sm font-bold text-slate-900 outline-none focus:ring-2 focus:ring-[#d4a853]/50 shadow-sm" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase ml-1">Senha de Acesso</label>
                    <input type="password" required value={formData.password} onChange={e => setFormData({...formData, password: e.target.value})} className="w-full bg-white border border-slate-200 rounded-xl py-3 px-4 text-sm font-bold text-slate-900 outline-none focus:ring-2 focus:ring-[#d4a853]/50 shadow-sm" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase ml-1">Nível de Função</label>
                    <select 
                      value={formData.role}
                      onChange={e => setFormData({...formData, role: e.target.value as UserRole})}
                      className="w-full bg-white border border-slate-200 rounded-xl py-3 px-4 text-sm font-bold text-slate-900 shadow-sm outline-none"
                    >
                      <option value="Broker">Corretor (Operacional)</option>
                      <option value="Admin">Administrador (Master)</option>
                    </select>
                  </div>
                </div>

                <div className="bg-white rounded-[2rem] p-6 border border-slate-200 shadow-sm flex flex-col">
                  <h3 className="text-[10px] font-black uppercase tracking-widest text-[#d4a853] mb-4 border-b border-slate-50 pb-3 flex items-center">
                    <ShieldIcon className="w-3.5 h-3.5 mr-2" />
                    Privilégios de Módulo
                  </h3>
                  <div className="space-y-2 overflow-y-auto max-h-56 pr-2 no-scrollbar">
                    {MODULES.map(m => (
                      <button 
                        key={m.id}
                        type="button"
                        onClick={() => togglePermission(m.id)}
                        disabled={formData.role === 'Admin'}
                        className={`w-full flex items-center justify-between p-2.5 rounded-xl border transition-all text-left ${
                          formData.role === 'Admin' || formData.permissions.includes(m.id)
                            ? 'bg-[#d4a853]/5 border-[#d4a853]/20 text-[#d4a853]' 
                            : 'bg-white border-slate-100 text-slate-400 hover:border-slate-300'
                        }`}
                      >
                        <span className="text-[9px] font-bold uppercase tracking-widest">{m.label}</span>
                        {formData.role === 'Admin' || formData.permissions.includes(m.id) ? (
                          <CheckSquare className="w-3.5 h-3.5" />
                        ) : (
                          <Square className="w-3.5 h-3.5" />
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
              <button type="submit" className="w-full gold-gradient text-white py-4 rounded-2xl font-black uppercase tracking-widest text-xs shadow-xl mt-4 hover:scale-[1.01] active:scale-95 transition-all flex items-center justify-center space-x-2">
                <Save className="w-4 h-4" />
                <span>{editingBroker ? 'Confirmar Alterações' : 'Finalizar Registro na Rede'}</span>
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
