
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.tsx';

const rootElement = document.getElementById('root');

if (!rootElement) {
  console.error("Elemento root não encontrado.");
} else {
  // Pequeno delay para garantir que o PeerJS e outras libs remotas via ESM.sh estejam prontas
  setTimeout(() => {
    try {
      const root = ReactDOM.createRoot(rootElement);
      root.render(
        <React.StrictMode>
          <App />
        </React.StrictMode>
      );
    } catch (error) {
      console.error("Erro fatal de inicialização:", error);
      rootElement.innerHTML = `
        <div style="padding: 40px; font-family: sans-serif; text-align: center; background: #0a1120; color: white; height: 100vh; display: flex; flex-direction: column; justify-content: center; align-items: center;">
          <h1 style="color: #d4a853;">Vettus CRM - Falha Crítica</h1>
          <p>Ocorreu um erro ao carregar o ecossistema P2P.</p>
          <pre style="background: rgba(255,255,255,0.05); padding: 20px; border-radius: 12px; font-size: 11px; max-width: 90%; overflow: auto; text-align: left;">${error}</pre>
          <button onclick="localStorage.clear(); location.reload();" style="margin-top: 20px; background: #d4a853; border: none; padding: 12px 24px; border-radius: 10px; cursor: pointer; font-weight: bold; color: #0a1120;">Limpar Cache e Reiniciar</button>
        </div>
      `;
    }
  }, 100);
}
